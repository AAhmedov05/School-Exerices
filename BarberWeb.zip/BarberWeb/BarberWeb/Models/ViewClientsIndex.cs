﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace BarberWeb.Models
{
    public class ViewClientsIndex
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string PhoneNumber { get; set; }
        public string Dates { get; set; }
        public string Fade { get; set; }
        public string Barber_Name { get; set; }
    }
}
