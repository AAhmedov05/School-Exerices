﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace BarberWeb.Models
{
    public class Client
    {
        public int Id { get; set; }
        public string Name { get; set; }
        [DataType(DataType.PhoneNumber)]
        public string PhoneNumber { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime Reservation { get; set; }
        public FadeTypes.Fades Fades { get; set; }
        [ForeignKey("Barber_Id")]
        public int Barber_Id { get; set; }
        public Barber Barber { get; set; }
    }
}
