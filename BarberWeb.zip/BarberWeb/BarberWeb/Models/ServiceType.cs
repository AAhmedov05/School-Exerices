﻿namespace BarberWeb.Models
{
    public class ServiceType
    {
        public enum Services 
        {
            Cheap,
            Normal,
            Expensive
        }
    }
}
