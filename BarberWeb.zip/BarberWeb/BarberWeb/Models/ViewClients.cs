﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace BarberWeb.Models
{
    public class ViewClients
    {
        public int Id { get; set; }
        public string Name { get; set; }
        [DataType(DataType.PhoneNumber)]

        [StringLength(10,MinimumLength =3,ErrorMessage = "The field {0} must be between {2} and {1}")]
        public string PhoneNumber { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime Reservation { get; set; }
        public FadeTypes.Fades Fades { get; set; }
        public int Barber_Id{ get; set; }

        public ICollection<Barber> Barbers { get; set; } = new List<Barber>();
    }
}
