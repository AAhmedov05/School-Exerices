﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BarberWeb.Models
{
    public class Reservation
    {
        [Key]
        public int Id { get; set; }
        [Required]
        public string Name { get; set; }
        [Required]
        [DataType(DataType.Date)]
        public DateTime MyProperty { get; set; }
        [ForeignKey(nameof(Barber))]
        public int Barber_Id { get; set; }
        public Barber Barber { get; set;}
    }
}
