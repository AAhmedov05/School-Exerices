﻿using BarberWeb.Data;
using BarberWeb.Models;
using Microsoft.EntityFrameworkCore;

namespace BarberWeb.Services
{
    public class BarberService : IBarbers
    {
        private ApplicationDbContext context;
        public BarberService(ApplicationDbContext _context)
        {
                this.context=_context;
        }
        public async Task AddBarber(Barber barber)
        {
            context.Barbers.Add(new Barber() {
                Id = barber.Id,
                Name = barber.Name,
                Address = barber.Address,
                Reservations = barber.Reservations,
                Image = barber.Image
            });
            await context.SaveChangesAsync();
        }

        public async Task<IEnumerable<Barber>> GetAllBarbers()
        {
            var barbers = await context.Barbers.ToListAsync();
            return barbers;
        }

        public async Task<Barber> GetBarberById(int id)
        {
            var theBarber = await context.Barbers.FindAsync(id);
            return theBarber;
        }

        public async Task RemoveBarber(int id)
        {
            var wantedBarber = context.Barbers.Find(id);
            if (wantedBarber != null) 
            {
                context.Barbers.Remove(wantedBarber);
                await context.SaveChangesAsync();
            }
        }

        public async Task UpdateBarber(Barber barber)
        {
            var barbers =  context.Barbers.Find(barber.Id);
            if (barbers != null)
            {
                context.Entry(barbers).CurrentValues.SetValues(barber);
                await context.SaveChangesAsync();
            }
        }
    }
}
