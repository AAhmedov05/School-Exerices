﻿using BarberWeb.Models;

namespace BarberWeb.Services
{
    public interface IBarbers
    {
        Task AddBarber(Barber barber);
        Task UpdateBarber(Barber barber);
        Task RemoveBarber(int id);  
        Task<IEnumerable<Barber>> GetAllBarbers();
        Task<Barber> GetBarberById(int id);
    }
}
