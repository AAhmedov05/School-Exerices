﻿using BarberWeb.Models;
using BarberWeb.Services;
using Microsoft.AspNetCore.Mvc;

namespace BarberWeb.Controllers
{
    public class BarberController : Controller
    {
        private BarberService barbers;
        public BarberController(BarberService _barbers)
        {
            this.barbers = _barbers;
        }

        public async Task<IActionResult> Index()
        {
            return View(await barbers.GetAllBarbers());
        }

        [HttpPost]
        public async Task<ActionResult> Create(Barber barber)
        {
            if (!ModelState.IsValid)
            {
                return View(barber);
            }
            await barbers.AddBarber(barber);
            return RedirectToAction(nameof(Index));
        }
        [HttpGet]
        public async Task<IActionResult> Edit(int id) 
        {
            var theBarber = await barbers.GetBarberById(id);
            return View(theBarber);
        }
        [HttpPost]
        public async Task<IActionResult> Edit(Barber barber) 
        {
            await barbers.UpdateBarber(barber);
            return View(barber);
        }
        [HttpGet]
        public async Task<IActionResult> Delete(int id)
        {
            if (barbers.GetBarberById(id)==null)
            {
                return NotFound();
            }
            return RedirectToAction(nameof(Index));
        }
        [HttpPost]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (await barbers.GetBarberById(id) != null)
            {
                await barbers.RemoveBarber(id);
            }
            return RedirectToAction(nameof(Index));
        }
    }
}
