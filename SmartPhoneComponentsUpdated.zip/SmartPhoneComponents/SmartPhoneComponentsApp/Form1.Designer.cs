﻿
namespace SmartPhoneComponentsApp
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPageBattery = new System.Windows.Forms.TabPage();
            this.lblTittle = new System.Windows.Forms.Label();
            this.btnSaveBattery = new System.Windows.Forms.Button();
            this.btnDeleteBattery = new System.Windows.Forms.Button();
            this.btnUpdateBattery = new System.Windows.Forms.Button();
            this.btnInsertBattery = new System.Windows.Forms.Button();
            this.dataGridViewBattery = new System.Windows.Forms.DataGridView();
            this.lblBatteryCapacity = new System.Windows.Forms.Label();
            this.txtBatteryCapacity = new System.Windows.Forms.TextBox();
            this.txtBatteryType = new System.Windows.Forms.TextBox();
            this.lblBatteryType = new System.Windows.Forms.Label();
            this.tabPageCamera = new System.Windows.Forms.TabPage();
            this.lblTitleCamera = new System.Windows.Forms.Label();
            this.btnSaveCamera = new System.Windows.Forms.Button();
            this.btnDeleteCamera = new System.Windows.Forms.Button();
            this.btnUpdateCamera = new System.Windows.Forms.Button();
            this.btnInsertCamera = new System.Windows.Forms.Button();
            this.dataGridViewCamera = new System.Windows.Forms.DataGridView();
            this.txtBoxRearCamera = new System.Windows.Forms.TextBox();
            this.txtBoxFrontCamera = new System.Windows.Forms.TextBox();
            this.lblRearCamera = new System.Windows.Forms.Label();
            this.lblFrontCamera = new System.Windows.Forms.Label();
            this.tabPageProcessor = new System.Windows.Forms.TabPage();
            this.lblTitleProcessors = new System.Windows.Forms.Label();
            this.btnSaveProcessor = new System.Windows.Forms.Button();
            this.btnDeleteProcessor = new System.Windows.Forms.Button();
            this.btnUpdateProcessor = new System.Windows.Forms.Button();
            this.btnInsertProcessor = new System.Windows.Forms.Button();
            this.dataGridViewProcessor = new System.Windows.Forms.DataGridView();
            this.txtBoxRAM = new System.Windows.Forms.TextBox();
            this.txtBoxFrequance = new System.Windows.Forms.TextBox();
            this.txtBoxNameProcessor = new System.Windows.Forms.TextBox();
            this.lblRamProcessor = new System.Windows.Forms.Label();
            this.lblFrequanceProcessor = new System.Windows.Forms.Label();
            this.lblNameProcessor = new System.Windows.Forms.Label();
            this.tabPageScreen = new System.Windows.Forms.TabPage();
            this.lblScreen = new System.Windows.Forms.Label();
            this.btnSaveScreen = new System.Windows.Forms.Button();
            this.btnDeleteScreen = new System.Windows.Forms.Button();
            this.btnUpdateScreen = new System.Windows.Forms.Button();
            this.btnInsertScreen = new System.Windows.Forms.Button();
            this.dataGridViewScreen = new System.Windows.Forms.DataGridView();
            this.txtBoxDisplayType = new System.Windows.Forms.TextBox();
            this.txtBoxRefreshRate = new System.Windows.Forms.TextBox();
            this.txtBoxDisplayResolution = new System.Windows.Forms.TextBox();
            this.txtBoxScreenSize = new System.Windows.Forms.TextBox();
            this.lblDisplayType = new System.Windows.Forms.Label();
            this.lblRefreshRate = new System.Windows.Forms.Label();
            this.lblDisplayResolution = new System.Windows.Forms.Label();
            this.lblScreenSize = new System.Windows.Forms.Label();
            this.tabPageSmartPhones = new System.Windows.Forms.TabPage();
            this.dateTimePickerSmartPhone = new System.Windows.Forms.DateTimePicker();
            this.btnSaveSmartPhone = new System.Windows.Forms.Button();
            this.btnDeleteSmartPhone = new System.Windows.Forms.Button();
            this.btnUpdateSmartPhone = new System.Windows.Forms.Button();
            this.btnInsertSmartPhone = new System.Windows.Forms.Button();
            this.lblTitleSmartPhones = new System.Windows.Forms.Label();
            this.txtBoxIMEI = new System.Windows.Forms.TextBox();
            this.txtBoxScreenID = new System.Windows.Forms.TextBox();
            this.txtBoxCameraID = new System.Windows.Forms.TextBox();
            this.txtBoxBatteryID = new System.Windows.Forms.TextBox();
            this.txtBoxProcessorID = new System.Windows.Forms.TextBox();
            this.txtBoxOS = new System.Windows.Forms.TextBox();
            this.txtBoxModel = new System.Windows.Forms.TextBox();
            this.txtBoxBrandName = new System.Windows.Forms.TextBox();
            this.dataGridViewSmartphones = new System.Windows.Forms.DataGridView();
            this.lblIMEI = new System.Windows.Forms.Label();
            this.lblScreenID = new System.Windows.Forms.Label();
            this.lblCameraID = new System.Windows.Forms.Label();
            this.lblBatteryID = new System.Windows.Forms.Label();
            this.lblProcessorID = new System.Windows.Forms.Label();
            this.lblOperationSystem = new System.Windows.Forms.Label();
            this.lblModel = new System.Windows.Forms.Label();
            this.lblBrandName = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.tabPageBattery.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewBattery)).BeginInit();
            this.tabPageCamera.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewCamera)).BeginInit();
            this.tabPageProcessor.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewProcessor)).BeginInit();
            this.tabPageScreen.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewScreen)).BeginInit();
            this.tabPageSmartPhones.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSmartphones)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPageBattery);
            this.tabControl1.Controls.Add(this.tabPageCamera);
            this.tabControl1.Controls.Add(this.tabPageProcessor);
            this.tabControl1.Controls.Add(this.tabPageScreen);
            this.tabControl1.Controls.Add(this.tabPageSmartPhones);
            this.tabControl1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.tabControl1.Location = new System.Drawing.Point(-4, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(807, 455);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPageBattery
            // 
            this.tabPageBattery.BackColor = System.Drawing.Color.Silver;
            this.tabPageBattery.BackgroundImage = global::SmartPhoneComponentsApp.Properties.Resources.battery_supply_concept_background_energy_efficiency_concept_power_energy_concept_background_battery_icon_digital_background_1656479761;
            this.tabPageBattery.Controls.Add(this.lblTittle);
            this.tabPageBattery.Controls.Add(this.btnSaveBattery);
            this.tabPageBattery.Controls.Add(this.btnDeleteBattery);
            this.tabPageBattery.Controls.Add(this.btnUpdateBattery);
            this.tabPageBattery.Controls.Add(this.btnInsertBattery);
            this.tabPageBattery.Controls.Add(this.dataGridViewBattery);
            this.tabPageBattery.Controls.Add(this.lblBatteryCapacity);
            this.tabPageBattery.Controls.Add(this.txtBatteryCapacity);
            this.tabPageBattery.Controls.Add(this.txtBatteryType);
            this.tabPageBattery.Controls.Add(this.lblBatteryType);
            this.tabPageBattery.Location = new System.Drawing.Point(4, 24);
            this.tabPageBattery.Name = "tabPageBattery";
            this.tabPageBattery.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageBattery.Size = new System.Drawing.Size(799, 427);
            this.tabPageBattery.TabIndex = 0;
            this.tabPageBattery.Text = "Battery";
            // 
            // lblTittle
            // 
            this.lblTittle.AutoSize = true;
            this.lblTittle.BackColor = System.Drawing.Color.Transparent;
            this.lblTittle.Font = new System.Drawing.Font("Segoe UI", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblTittle.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.lblTittle.Location = new System.Drawing.Point(133, 42);
            this.lblTittle.Name = "lblTittle";
            this.lblTittle.Size = new System.Drawing.Size(166, 47);
            this.lblTittle.TabIndex = 9;
            this.lblTittle.Text = "Batteries";
            this.lblTittle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnSaveBattery
            // 
            this.btnSaveBattery.Location = new System.Drawing.Point(160, 229);
            this.btnSaveBattery.Name = "btnSaveBattery";
            this.btnSaveBattery.Size = new System.Drawing.Size(104, 32);
            this.btnSaveBattery.TabIndex = 8;
            this.btnSaveBattery.Text = "Save";
            this.btnSaveBattery.UseVisualStyleBackColor = true;
            this.btnSaveBattery.Visible = false;
            this.btnSaveBattery.Click += new System.EventHandler(this.btnSaveBattery_Click);
            // 
            // btnDeleteBattery
            // 
            this.btnDeleteBattery.Location = new System.Drawing.Point(270, 229);
            this.btnDeleteBattery.Name = "btnDeleteBattery";
            this.btnDeleteBattery.Size = new System.Drawing.Size(104, 32);
            this.btnDeleteBattery.TabIndex = 7;
            this.btnDeleteBattery.Text = "Delete";
            this.btnDeleteBattery.UseVisualStyleBackColor = true;
            this.btnDeleteBattery.Click += new System.EventHandler(this.btnDeleteBattery_Click);
            // 
            // btnUpdateBattery
            // 
            this.btnUpdateBattery.Location = new System.Drawing.Point(160, 229);
            this.btnUpdateBattery.Name = "btnUpdateBattery";
            this.btnUpdateBattery.Size = new System.Drawing.Size(104, 32);
            this.btnUpdateBattery.TabIndex = 6;
            this.btnUpdateBattery.Text = "Update";
            this.btnUpdateBattery.UseVisualStyleBackColor = true;
            this.btnUpdateBattery.Click += new System.EventHandler(this.btnUpdateBattery_Click);
            // 
            // btnInsertBattery
            // 
            this.btnInsertBattery.Location = new System.Drawing.Point(62, 229);
            this.btnInsertBattery.Name = "btnInsertBattery";
            this.btnInsertBattery.Size = new System.Drawing.Size(92, 32);
            this.btnInsertBattery.TabIndex = 5;
            this.btnInsertBattery.Text = "Insert";
            this.btnInsertBattery.UseVisualStyleBackColor = true;
            this.btnInsertBattery.Click += new System.EventHandler(this.btnInsertBattery_Click);
            // 
            // dataGridViewBattery
            // 
            this.dataGridViewBattery.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewBattery.Location = new System.Drawing.Point(412, 6);
            this.dataGridViewBattery.Name = "dataGridViewBattery";
            this.dataGridViewBattery.RowTemplate.Height = 25;
            this.dataGridViewBattery.Size = new System.Drawing.Size(381, 295);
            this.dataGridViewBattery.TabIndex = 4;
            // 
            // lblBatteryCapacity
            // 
            this.lblBatteryCapacity.AutoSize = true;
            this.lblBatteryCapacity.BackColor = System.Drawing.Color.Transparent;
            this.lblBatteryCapacity.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblBatteryCapacity.ForeColor = System.Drawing.SystemColors.Control;
            this.lblBatteryCapacity.Location = new System.Drawing.Point(78, 173);
            this.lblBatteryCapacity.Name = "lblBatteryCapacity";
            this.lblBatteryCapacity.Size = new System.Drawing.Size(148, 25);
            this.lblBatteryCapacity.TabIndex = 3;
            this.lblBatteryCapacity.Text = "Battery Capacity";
            // 
            // txtBatteryCapacity
            // 
            this.txtBatteryCapacity.Location = new System.Drawing.Point(232, 175);
            this.txtBatteryCapacity.Name = "txtBatteryCapacity";
            this.txtBatteryCapacity.Size = new System.Drawing.Size(129, 23);
            this.txtBatteryCapacity.TabIndex = 2;
            // 
            // txtBatteryType
            // 
            this.txtBatteryType.Location = new System.Drawing.Point(199, 129);
            this.txtBatteryType.Name = "txtBatteryType";
            this.txtBatteryType.Size = new System.Drawing.Size(162, 23);
            this.txtBatteryType.TabIndex = 1;
            // 
            // lblBatteryType
            // 
            this.lblBatteryType.AutoSize = true;
            this.lblBatteryType.BackColor = System.Drawing.Color.Transparent;
            this.lblBatteryType.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblBatteryType.ForeColor = System.Drawing.Color.Transparent;
            this.lblBatteryType.Location = new System.Drawing.Point(78, 127);
            this.lblBatteryType.Name = "lblBatteryType";
            this.lblBatteryType.Size = new System.Drawing.Size(116, 25);
            this.lblBatteryType.TabIndex = 0;
            this.lblBatteryType.Text = "Battery Type";
            // 
            // tabPageCamera
            // 
            this.tabPageCamera.BackColor = System.Drawing.Color.Moccasin;
            this.tabPageCamera.Controls.Add(this.lblTitleCamera);
            this.tabPageCamera.Controls.Add(this.btnSaveCamera);
            this.tabPageCamera.Controls.Add(this.btnDeleteCamera);
            this.tabPageCamera.Controls.Add(this.btnUpdateCamera);
            this.tabPageCamera.Controls.Add(this.btnInsertCamera);
            this.tabPageCamera.Controls.Add(this.dataGridViewCamera);
            this.tabPageCamera.Controls.Add(this.txtBoxRearCamera);
            this.tabPageCamera.Controls.Add(this.txtBoxFrontCamera);
            this.tabPageCamera.Controls.Add(this.lblRearCamera);
            this.tabPageCamera.Controls.Add(this.lblFrontCamera);
            this.tabPageCamera.Location = new System.Drawing.Point(4, 24);
            this.tabPageCamera.Name = "tabPageCamera";
            this.tabPageCamera.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageCamera.Size = new System.Drawing.Size(799, 427);
            this.tabPageCamera.TabIndex = 1;
            this.tabPageCamera.Text = "Camera";
            // 
            // lblTitleCamera
            // 
            this.lblTitleCamera.AutoSize = true;
            this.lblTitleCamera.Font = new System.Drawing.Font("Showcard Gothic", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblTitleCamera.Location = new System.Drawing.Point(91, 47);
            this.lblTitleCamera.Name = "lblTitleCamera";
            this.lblTitleCamera.Size = new System.Drawing.Size(160, 40);
            this.lblTitleCamera.TabIndex = 9;
            this.lblTitleCamera.Text = "Cameras";
            // 
            // btnSaveCamera
            // 
            this.btnSaveCamera.Font = new System.Drawing.Font("Rockwell", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnSaveCamera.Location = new System.Drawing.Point(128, 259);
            this.btnSaveCamera.Name = "btnSaveCamera";
            this.btnSaveCamera.Size = new System.Drawing.Size(89, 42);
            this.btnSaveCamera.TabIndex = 8;
            this.btnSaveCamera.Text = "Save";
            this.btnSaveCamera.UseVisualStyleBackColor = true;
            this.btnSaveCamera.Visible = false;
            this.btnSaveCamera.Click += new System.EventHandler(this.btnSaveCamera_Click);
            // 
            // btnDeleteCamera
            // 
            this.btnDeleteCamera.Font = new System.Drawing.Font("Rockwell", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnDeleteCamera.Location = new System.Drawing.Point(234, 259);
            this.btnDeleteCamera.Name = "btnDeleteCamera";
            this.btnDeleteCamera.Size = new System.Drawing.Size(81, 44);
            this.btnDeleteCamera.TabIndex = 7;
            this.btnDeleteCamera.Text = "Delete";
            this.btnDeleteCamera.UseVisualStyleBackColor = true;
            this.btnDeleteCamera.Click += new System.EventHandler(this.btnDeleteCamera_Click);
            // 
            // btnUpdateCamera
            // 
            this.btnUpdateCamera.Font = new System.Drawing.Font("Rockwell", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnUpdateCamera.Location = new System.Drawing.Point(128, 259);
            this.btnUpdateCamera.Name = "btnUpdateCamera";
            this.btnUpdateCamera.Size = new System.Drawing.Size(89, 42);
            this.btnUpdateCamera.TabIndex = 6;
            this.btnUpdateCamera.Text = "Update";
            this.btnUpdateCamera.UseVisualStyleBackColor = true;
            this.btnUpdateCamera.Click += new System.EventHandler(this.btnUpdateCamera_Click);
            // 
            // btnInsertCamera
            // 
            this.btnInsertCamera.Font = new System.Drawing.Font("Rockwell", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnInsertCamera.Location = new System.Drawing.Point(38, 259);
            this.btnInsertCamera.Name = "btnInsertCamera";
            this.btnInsertCamera.Size = new System.Drawing.Size(84, 42);
            this.btnInsertCamera.TabIndex = 5;
            this.btnInsertCamera.Text = "Insert";
            this.btnInsertCamera.UseVisualStyleBackColor = true;
            this.btnInsertCamera.Click += new System.EventHandler(this.btnInsertCamera_Click);
            // 
            // dataGridViewCamera
            // 
            this.dataGridViewCamera.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewCamera.Location = new System.Drawing.Point(349, 6);
            this.dataGridViewCamera.Name = "dataGridViewCamera";
            this.dataGridViewCamera.RowTemplate.Height = 25;
            this.dataGridViewCamera.Size = new System.Drawing.Size(444, 295);
            this.dataGridViewCamera.TabIndex = 4;
            // 
            // txtBoxRearCamera
            // 
            this.txtBoxRearCamera.Location = new System.Drawing.Point(170, 196);
            this.txtBoxRearCamera.Name = "txtBoxRearCamera";
            this.txtBoxRearCamera.Size = new System.Drawing.Size(126, 23);
            this.txtBoxRearCamera.TabIndex = 3;
            // 
            // txtBoxFrontCamera
            // 
            this.txtBoxFrontCamera.Location = new System.Drawing.Point(170, 156);
            this.txtBoxFrontCamera.Name = "txtBoxFrontCamera";
            this.txtBoxFrontCamera.Size = new System.Drawing.Size(126, 23);
            this.txtBoxFrontCamera.TabIndex = 2;
            // 
            // lblRearCamera
            // 
            this.lblRearCamera.AutoSize = true;
            this.lblRearCamera.Font = new System.Drawing.Font("Rockwell", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblRearCamera.Location = new System.Drawing.Point(38, 194);
            this.lblRearCamera.Name = "lblRearCamera";
            this.lblRearCamera.Size = new System.Drawing.Size(124, 21);
            this.lblRearCamera.TabIndex = 1;
            this.lblRearCamera.Text = "Rear Camera";
            // 
            // lblFrontCamera
            // 
            this.lblFrontCamera.AutoSize = true;
            this.lblFrontCamera.Font = new System.Drawing.Font("Rockwell", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblFrontCamera.Location = new System.Drawing.Point(38, 154);
            this.lblFrontCamera.Name = "lblFrontCamera";
            this.lblFrontCamera.Size = new System.Drawing.Size(130, 21);
            this.lblFrontCamera.TabIndex = 0;
            this.lblFrontCamera.Text = "Front Camera";
            // 
            // tabPageProcessor
            // 
            this.tabPageProcessor.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.tabPageProcessor.Controls.Add(this.lblTitleProcessors);
            this.tabPageProcessor.Controls.Add(this.btnSaveProcessor);
            this.tabPageProcessor.Controls.Add(this.btnDeleteProcessor);
            this.tabPageProcessor.Controls.Add(this.btnUpdateProcessor);
            this.tabPageProcessor.Controls.Add(this.btnInsertProcessor);
            this.tabPageProcessor.Controls.Add(this.dataGridViewProcessor);
            this.tabPageProcessor.Controls.Add(this.txtBoxRAM);
            this.tabPageProcessor.Controls.Add(this.txtBoxFrequance);
            this.tabPageProcessor.Controls.Add(this.txtBoxNameProcessor);
            this.tabPageProcessor.Controls.Add(this.lblRamProcessor);
            this.tabPageProcessor.Controls.Add(this.lblFrequanceProcessor);
            this.tabPageProcessor.Controls.Add(this.lblNameProcessor);
            this.tabPageProcessor.Location = new System.Drawing.Point(4, 24);
            this.tabPageProcessor.Name = "tabPageProcessor";
            this.tabPageProcessor.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageProcessor.Size = new System.Drawing.Size(799, 427);
            this.tabPageProcessor.TabIndex = 2;
            this.tabPageProcessor.Text = "Processor";
            // 
            // lblTitleProcessors
            // 
            this.lblTitleProcessors.AutoSize = true;
            this.lblTitleProcessors.Font = new System.Drawing.Font("Sitka Text", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblTitleProcessors.Location = new System.Drawing.Point(77, 32);
            this.lblTitleProcessors.Name = "lblTitleProcessors";
            this.lblTitleProcessors.Size = new System.Drawing.Size(210, 50);
            this.lblTitleProcessors.TabIndex = 13;
            this.lblTitleProcessors.Text = "Processors";
            // 
            // btnSaveProcessor
            // 
            this.btnSaveProcessor.Font = new System.Drawing.Font("Sitka Text", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnSaveProcessor.Location = new System.Drawing.Point(137, 262);
            this.btnSaveProcessor.Name = "btnSaveProcessor";
            this.btnSaveProcessor.Size = new System.Drawing.Size(81, 30);
            this.btnSaveProcessor.TabIndex = 12;
            this.btnSaveProcessor.Text = "Save";
            this.btnSaveProcessor.UseVisualStyleBackColor = true;
            this.btnSaveProcessor.Visible = false;
            this.btnSaveProcessor.Click += new System.EventHandler(this.btnSaveProcessor_Click);
            // 
            // btnDeleteProcessor
            // 
            this.btnDeleteProcessor.Font = new System.Drawing.Font("Sitka Text", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnDeleteProcessor.Location = new System.Drawing.Point(224, 262);
            this.btnDeleteProcessor.Name = "btnDeleteProcessor";
            this.btnDeleteProcessor.Size = new System.Drawing.Size(81, 30);
            this.btnDeleteProcessor.TabIndex = 11;
            this.btnDeleteProcessor.Text = "Delete";
            this.btnDeleteProcessor.UseVisualStyleBackColor = true;
            this.btnDeleteProcessor.Click += new System.EventHandler(this.btnDeleteProcessor_Click);
            // 
            // btnUpdateProcessor
            // 
            this.btnUpdateProcessor.Font = new System.Drawing.Font("Sitka Text", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnUpdateProcessor.Location = new System.Drawing.Point(137, 262);
            this.btnUpdateProcessor.Name = "btnUpdateProcessor";
            this.btnUpdateProcessor.Size = new System.Drawing.Size(81, 30);
            this.btnUpdateProcessor.TabIndex = 10;
            this.btnUpdateProcessor.Text = "Update";
            this.btnUpdateProcessor.UseVisualStyleBackColor = true;
            this.btnUpdateProcessor.Click += new System.EventHandler(this.btnUpdateProcessor_Click);
            // 
            // btnInsertProcessor
            // 
            this.btnInsertProcessor.Font = new System.Drawing.Font("Sitka Text", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnInsertProcessor.Location = new System.Drawing.Point(50, 262);
            this.btnInsertProcessor.Name = "btnInsertProcessor";
            this.btnInsertProcessor.Size = new System.Drawing.Size(81, 30);
            this.btnInsertProcessor.TabIndex = 9;
            this.btnInsertProcessor.Text = "Insert";
            this.btnInsertProcessor.UseVisualStyleBackColor = true;
            this.btnInsertProcessor.Click += new System.EventHandler(this.btnInsertProcessor_Click);
            // 
            // dataGridViewProcessor
            // 
            this.dataGridViewProcessor.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewProcessor.Location = new System.Drawing.Point(375, 6);
            this.dataGridViewProcessor.Name = "dataGridViewProcessor";
            this.dataGridViewProcessor.RowTemplate.Height = 25;
            this.dataGridViewProcessor.Size = new System.Drawing.Size(418, 225);
            this.dataGridViewProcessor.TabIndex = 6;
            // 
            // txtBoxRAM
            // 
            this.txtBoxRAM.Location = new System.Drawing.Point(135, 208);
            this.txtBoxRAM.Name = "txtBoxRAM";
            this.txtBoxRAM.Size = new System.Drawing.Size(148, 23);
            this.txtBoxRAM.TabIndex = 5;
            // 
            // txtBoxFrequance
            // 
            this.txtBoxFrequance.Location = new System.Drawing.Point(183, 169);
            this.txtBoxFrequance.Name = "txtBoxFrequance";
            this.txtBoxFrequance.Size = new System.Drawing.Size(100, 23);
            this.txtBoxFrequance.TabIndex = 4;
            // 
            // txtBoxNameProcessor
            // 
            this.txtBoxNameProcessor.Location = new System.Drawing.Point(145, 136);
            this.txtBoxNameProcessor.Name = "txtBoxNameProcessor";
            this.txtBoxNameProcessor.Size = new System.Drawing.Size(138, 23);
            this.txtBoxNameProcessor.TabIndex = 3;
            // 
            // lblRamProcessor
            // 
            this.lblRamProcessor.AutoSize = true;
            this.lblRamProcessor.Font = new System.Drawing.Font("Sitka Text", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblRamProcessor.Location = new System.Drawing.Point(77, 203);
            this.lblRamProcessor.Name = "lblRamProcessor";
            this.lblRamProcessor.Size = new System.Drawing.Size(56, 28);
            this.lblRamProcessor.TabIndex = 2;
            this.lblRamProcessor.Text = "RAM";
            // 
            // lblFrequanceProcessor
            // 
            this.lblFrequanceProcessor.AutoSize = true;
            this.lblFrequanceProcessor.Font = new System.Drawing.Font("Sitka Text", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblFrequanceProcessor.Location = new System.Drawing.Point(77, 164);
            this.lblFrequanceProcessor.Name = "lblFrequanceProcessor";
            this.lblFrequanceProcessor.Size = new System.Drawing.Size(109, 28);
            this.lblFrequanceProcessor.TabIndex = 1;
            this.lblFrequanceProcessor.Text = "Frequance";
            // 
            // lblNameProcessor
            // 
            this.lblNameProcessor.AutoSize = true;
            this.lblNameProcessor.Font = new System.Drawing.Font("Sitka Text", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblNameProcessor.Location = new System.Drawing.Point(77, 131);
            this.lblNameProcessor.Name = "lblNameProcessor";
            this.lblNameProcessor.Size = new System.Drawing.Size(66, 28);
            this.lblNameProcessor.TabIndex = 0;
            this.lblNameProcessor.Text = "Name";
            // 
            // tabPageScreen
            // 
            this.tabPageScreen.BackColor = System.Drawing.Color.PowderBlue;
            this.tabPageScreen.Controls.Add(this.lblScreen);
            this.tabPageScreen.Controls.Add(this.btnSaveScreen);
            this.tabPageScreen.Controls.Add(this.btnDeleteScreen);
            this.tabPageScreen.Controls.Add(this.btnUpdateScreen);
            this.tabPageScreen.Controls.Add(this.btnInsertScreen);
            this.tabPageScreen.Controls.Add(this.dataGridViewScreen);
            this.tabPageScreen.Controls.Add(this.txtBoxDisplayType);
            this.tabPageScreen.Controls.Add(this.txtBoxRefreshRate);
            this.tabPageScreen.Controls.Add(this.txtBoxDisplayResolution);
            this.tabPageScreen.Controls.Add(this.txtBoxScreenSize);
            this.tabPageScreen.Controls.Add(this.lblDisplayType);
            this.tabPageScreen.Controls.Add(this.lblRefreshRate);
            this.tabPageScreen.Controls.Add(this.lblDisplayResolution);
            this.tabPageScreen.Controls.Add(this.lblScreenSize);
            this.tabPageScreen.Location = new System.Drawing.Point(4, 24);
            this.tabPageScreen.Name = "tabPageScreen";
            this.tabPageScreen.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageScreen.Size = new System.Drawing.Size(799, 427);
            this.tabPageScreen.TabIndex = 3;
            this.tabPageScreen.Text = "Screen";
            // 
            // lblScreen
            // 
            this.lblScreen.AutoSize = true;
            this.lblScreen.Font = new System.Drawing.Font("Sitka Text", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblScreen.Location = new System.Drawing.Point(147, 32);
            this.lblScreen.Name = "lblScreen";
            this.lblScreen.Size = new System.Drawing.Size(125, 47);
            this.lblScreen.TabIndex = 17;
            this.lblScreen.Text = "Screen";
            this.lblScreen.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnSaveScreen
            // 
            this.btnSaveScreen.Location = new System.Drawing.Point(163, 273);
            this.btnSaveScreen.Name = "btnSaveScreen";
            this.btnSaveScreen.Size = new System.Drawing.Size(81, 30);
            this.btnSaveScreen.TabIndex = 16;
            this.btnSaveScreen.Text = "Save";
            this.btnSaveScreen.UseVisualStyleBackColor = true;
            this.btnSaveScreen.Visible = false;
            this.btnSaveScreen.Click += new System.EventHandler(this.btnSaveScreen_Click);
            // 
            // btnDeleteScreen
            // 
            this.btnDeleteScreen.Location = new System.Drawing.Point(250, 273);
            this.btnDeleteScreen.Name = "btnDeleteScreen";
            this.btnDeleteScreen.Size = new System.Drawing.Size(81, 30);
            this.btnDeleteScreen.TabIndex = 15;
            this.btnDeleteScreen.Text = "Delete";
            this.btnDeleteScreen.UseVisualStyleBackColor = true;
            this.btnDeleteScreen.Click += new System.EventHandler(this.btnDeleteScreen_Click);
            // 
            // btnUpdateScreen
            // 
            this.btnUpdateScreen.Location = new System.Drawing.Point(163, 273);
            this.btnUpdateScreen.Name = "btnUpdateScreen";
            this.btnUpdateScreen.Size = new System.Drawing.Size(81, 30);
            this.btnUpdateScreen.TabIndex = 14;
            this.btnUpdateScreen.Text = "Update";
            this.btnUpdateScreen.UseVisualStyleBackColor = true;
            this.btnUpdateScreen.Click += new System.EventHandler(this.btnUpdateScreen_Click);
            // 
            // btnInsertScreen
            // 
            this.btnInsertScreen.Location = new System.Drawing.Point(76, 273);
            this.btnInsertScreen.Name = "btnInsertScreen";
            this.btnInsertScreen.Size = new System.Drawing.Size(81, 30);
            this.btnInsertScreen.TabIndex = 13;
            this.btnInsertScreen.Text = "Insert";
            this.btnInsertScreen.UseVisualStyleBackColor = true;
            this.btnInsertScreen.Click += new System.EventHandler(this.btnInsertScreen_Click);
            // 
            // dataGridViewScreen
            // 
            this.dataGridViewScreen.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewScreen.Location = new System.Drawing.Point(402, 6);
            this.dataGridViewScreen.Name = "dataGridViewScreen";
            this.dataGridViewScreen.RowTemplate.Height = 25;
            this.dataGridViewScreen.Size = new System.Drawing.Size(391, 236);
            this.dataGridViewScreen.TabIndex = 8;
            // 
            // txtBoxDisplayType
            // 
            this.txtBoxDisplayType.Location = new System.Drawing.Point(182, 227);
            this.txtBoxDisplayType.Name = "txtBoxDisplayType";
            this.txtBoxDisplayType.Size = new System.Drawing.Size(149, 23);
            this.txtBoxDisplayType.TabIndex = 7;
            // 
            // txtBoxRefreshRate
            // 
            this.txtBoxRefreshRate.Location = new System.Drawing.Point(184, 198);
            this.txtBoxRefreshRate.Name = "txtBoxRefreshRate";
            this.txtBoxRefreshRate.Size = new System.Drawing.Size(148, 23);
            this.txtBoxRefreshRate.TabIndex = 6;
            // 
            // txtBoxDisplayResolution
            // 
            this.txtBoxDisplayResolution.Location = new System.Drawing.Point(233, 170);
            this.txtBoxDisplayResolution.Name = "txtBoxDisplayResolution";
            this.txtBoxDisplayResolution.Size = new System.Drawing.Size(99, 23);
            this.txtBoxDisplayResolution.TabIndex = 5;
            // 
            // txtBoxScreenSize
            // 
            this.txtBoxScreenSize.Location = new System.Drawing.Point(175, 135);
            this.txtBoxScreenSize.Name = "txtBoxScreenSize";
            this.txtBoxScreenSize.Size = new System.Drawing.Size(157, 23);
            this.txtBoxScreenSize.TabIndex = 4;
            // 
            // lblDisplayType
            // 
            this.lblDisplayType.AutoSize = true;
            this.lblDisplayType.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblDisplayType.Location = new System.Drawing.Point(58, 225);
            this.lblDisplayType.Name = "lblDisplayType";
            this.lblDisplayType.Size = new System.Drawing.Size(118, 25);
            this.lblDisplayType.TabIndex = 3;
            this.lblDisplayType.Text = "Display Type";
            this.lblDisplayType.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblRefreshRate
            // 
            this.lblRefreshRate.AutoSize = true;
            this.lblRefreshRate.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblRefreshRate.Location = new System.Drawing.Point(58, 196);
            this.lblRefreshRate.Name = "lblRefreshRate";
            this.lblRefreshRate.Size = new System.Drawing.Size(117, 25);
            this.lblRefreshRate.TabIndex = 2;
            this.lblRefreshRate.Text = "Refresh Rate";
            this.lblRefreshRate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblDisplayResolution
            // 
            this.lblDisplayResolution.AutoSize = true;
            this.lblDisplayResolution.Font = new System.Drawing.Font("Sitka Text", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblDisplayResolution.Location = new System.Drawing.Point(58, 165);
            this.lblDisplayResolution.Name = "lblDisplayResolution";
            this.lblDisplayResolution.Size = new System.Drawing.Size(178, 28);
            this.lblDisplayResolution.TabIndex = 1;
            this.lblDisplayResolution.Text = "Display Resolution";
            this.lblDisplayResolution.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblScreenSize
            // 
            this.lblScreenSize.AutoSize = true;
            this.lblScreenSize.Font = new System.Drawing.Font("Sitka Text", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblScreenSize.Location = new System.Drawing.Point(58, 130);
            this.lblScreenSize.Name = "lblScreenSize";
            this.lblScreenSize.Size = new System.Drawing.Size(114, 28);
            this.lblScreenSize.TabIndex = 0;
            this.lblScreenSize.Text = "Screen Size";
            this.lblScreenSize.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tabPageSmartPhones
            // 
            this.tabPageSmartPhones.BackColor = System.Drawing.Color.LightCyan;
            this.tabPageSmartPhones.Controls.Add(this.dateTimePickerSmartPhone);
            this.tabPageSmartPhones.Controls.Add(this.btnSaveSmartPhone);
            this.tabPageSmartPhones.Controls.Add(this.btnDeleteSmartPhone);
            this.tabPageSmartPhones.Controls.Add(this.btnUpdateSmartPhone);
            this.tabPageSmartPhones.Controls.Add(this.btnInsertSmartPhone);
            this.tabPageSmartPhones.Controls.Add(this.lblTitleSmartPhones);
            this.tabPageSmartPhones.Controls.Add(this.txtBoxIMEI);
            this.tabPageSmartPhones.Controls.Add(this.txtBoxScreenID);
            this.tabPageSmartPhones.Controls.Add(this.txtBoxCameraID);
            this.tabPageSmartPhones.Controls.Add(this.txtBoxBatteryID);
            this.tabPageSmartPhones.Controls.Add(this.txtBoxProcessorID);
            this.tabPageSmartPhones.Controls.Add(this.txtBoxOS);
            this.tabPageSmartPhones.Controls.Add(this.txtBoxModel);
            this.tabPageSmartPhones.Controls.Add(this.txtBoxBrandName);
            this.tabPageSmartPhones.Controls.Add(this.dataGridViewSmartphones);
            this.tabPageSmartPhones.Controls.Add(this.lblIMEI);
            this.tabPageSmartPhones.Controls.Add(this.lblScreenID);
            this.tabPageSmartPhones.Controls.Add(this.lblCameraID);
            this.tabPageSmartPhones.Controls.Add(this.lblBatteryID);
            this.tabPageSmartPhones.Controls.Add(this.lblProcessorID);
            this.tabPageSmartPhones.Controls.Add(this.lblOperationSystem);
            this.tabPageSmartPhones.Controls.Add(this.lblModel);
            this.tabPageSmartPhones.Controls.Add(this.lblBrandName);
            this.tabPageSmartPhones.Location = new System.Drawing.Point(4, 24);
            this.tabPageSmartPhones.Name = "tabPageSmartPhones";
            this.tabPageSmartPhones.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageSmartPhones.Size = new System.Drawing.Size(799, 427);
            this.tabPageSmartPhones.TabIndex = 4;
            this.tabPageSmartPhones.Text = "SmartPhones";
            // 
            // dateTimePickerSmartPhone
            // 
            this.dateTimePickerSmartPhone.Location = new System.Drawing.Point(31, 370);
            this.dateTimePickerSmartPhone.Name = "dateTimePickerSmartPhone";
            this.dateTimePickerSmartPhone.Size = new System.Drawing.Size(204, 23);
            this.dateTimePickerSmartPhone.TabIndex = 23;
            // 
            // btnSaveSmartPhone
            // 
            this.btnSaveSmartPhone.Location = new System.Drawing.Point(269, 314);
            this.btnSaveSmartPhone.Name = "btnSaveSmartPhone";
            this.btnSaveSmartPhone.Size = new System.Drawing.Size(81, 30);
            this.btnSaveSmartPhone.TabIndex = 22;
            this.btnSaveSmartPhone.Text = "Save";
            this.btnSaveSmartPhone.UseVisualStyleBackColor = true;
            this.btnSaveSmartPhone.Visible = false;
            this.btnSaveSmartPhone.Click += new System.EventHandler(this.btnSaveSmartPhone_Click);
            // 
            // btnDeleteSmartPhone
            // 
            this.btnDeleteSmartPhone.Location = new System.Drawing.Point(269, 350);
            this.btnDeleteSmartPhone.Name = "btnDeleteSmartPhone";
            this.btnDeleteSmartPhone.Size = new System.Drawing.Size(81, 30);
            this.btnDeleteSmartPhone.TabIndex = 21;
            this.btnDeleteSmartPhone.Text = "Delete";
            this.btnDeleteSmartPhone.UseVisualStyleBackColor = true;
            this.btnDeleteSmartPhone.Click += new System.EventHandler(this.btnDeleteSmartPhone_Click);
            // 
            // btnUpdateSmartPhone
            // 
            this.btnUpdateSmartPhone.Location = new System.Drawing.Point(269, 314);
            this.btnUpdateSmartPhone.Name = "btnUpdateSmartPhone";
            this.btnUpdateSmartPhone.Size = new System.Drawing.Size(81, 30);
            this.btnUpdateSmartPhone.TabIndex = 20;
            this.btnUpdateSmartPhone.Text = "Update";
            this.btnUpdateSmartPhone.UseVisualStyleBackColor = true;
            this.btnUpdateSmartPhone.Click += new System.EventHandler(this.btnUpdateSmartPhone_Click);
            // 
            // btnInsertSmartPhone
            // 
            this.btnInsertSmartPhone.Location = new System.Drawing.Point(269, 278);
            this.btnInsertSmartPhone.Name = "btnInsertSmartPhone";
            this.btnInsertSmartPhone.Size = new System.Drawing.Size(81, 30);
            this.btnInsertSmartPhone.TabIndex = 19;
            this.btnInsertSmartPhone.Text = "Insert";
            this.btnInsertSmartPhone.UseVisualStyleBackColor = true;
            this.btnInsertSmartPhone.Click += new System.EventHandler(this.btnInsertSmartPhone_Click);
            // 
            // lblTitleSmartPhones
            // 
            this.lblTitleSmartPhones.AutoSize = true;
            this.lblTitleSmartPhones.Font = new System.Drawing.Font("Times New Roman", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblTitleSmartPhones.Location = new System.Drawing.Point(81, 16);
            this.lblTitleSmartPhones.Name = "lblTitleSmartPhones";
            this.lblTitleSmartPhones.Size = new System.Drawing.Size(199, 36);
            this.lblTitleSmartPhones.TabIndex = 18;
            this.lblTitleSmartPhones.Text = "SmartPhones";
            // 
            // txtBoxIMEI
            // 
            this.txtBoxIMEI.Location = new System.Drawing.Point(86, 341);
            this.txtBoxIMEI.Name = "txtBoxIMEI";
            this.txtBoxIMEI.Size = new System.Drawing.Size(149, 23);
            this.txtBoxIMEI.TabIndex = 17;
            // 
            // txtBoxScreenID
            // 
            this.txtBoxScreenID.Location = new System.Drawing.Point(124, 312);
            this.txtBoxScreenID.Name = "txtBoxScreenID";
            this.txtBoxScreenID.Size = new System.Drawing.Size(111, 23);
            this.txtBoxScreenID.TabIndex = 16;
            // 
            // txtBoxCameraID
            // 
            this.txtBoxCameraID.Location = new System.Drawing.Point(124, 283);
            this.txtBoxCameraID.Name = "txtBoxCameraID";
            this.txtBoxCameraID.Size = new System.Drawing.Size(111, 23);
            this.txtBoxCameraID.TabIndex = 15;
            // 
            // txtBoxBatteryID
            // 
            this.txtBoxBatteryID.Location = new System.Drawing.Point(124, 254);
            this.txtBoxBatteryID.Name = "txtBoxBatteryID";
            this.txtBoxBatteryID.Size = new System.Drawing.Size(111, 23);
            this.txtBoxBatteryID.TabIndex = 14;
            // 
            // txtBoxProcessorID
            // 
            this.txtBoxProcessorID.Location = new System.Drawing.Point(147, 226);
            this.txtBoxProcessorID.Name = "txtBoxProcessorID";
            this.txtBoxProcessorID.Size = new System.Drawing.Size(88, 23);
            this.txtBoxProcessorID.TabIndex = 13;
            // 
            // txtBoxOS
            // 
            this.txtBoxOS.Location = new System.Drawing.Point(181, 196);
            this.txtBoxOS.Name = "txtBoxOS";
            this.txtBoxOS.Size = new System.Drawing.Size(54, 23);
            this.txtBoxOS.TabIndex = 12;
            // 
            // txtBoxModel
            // 
            this.txtBoxModel.Location = new System.Drawing.Point(95, 167);
            this.txtBoxModel.Name = "txtBoxModel";
            this.txtBoxModel.Size = new System.Drawing.Size(140, 23);
            this.txtBoxModel.TabIndex = 11;
            // 
            // txtBoxBrandName
            // 
            this.txtBoxBrandName.Location = new System.Drawing.Point(140, 138);
            this.txtBoxBrandName.Name = "txtBoxBrandName";
            this.txtBoxBrandName.Size = new System.Drawing.Size(95, 23);
            this.txtBoxBrandName.TabIndex = 10;
            // 
            // dataGridViewSmartphones
            // 
            this.dataGridViewSmartphones.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewSmartphones.Location = new System.Drawing.Point(362, 0);
            this.dataGridViewSmartphones.Name = "dataGridViewSmartphones";
            this.dataGridViewSmartphones.RowTemplate.Height = 25;
            this.dataGridViewSmartphones.Size = new System.Drawing.Size(437, 246);
            this.dataGridViewSmartphones.TabIndex = 8;
            // 
            // lblIMEI
            // 
            this.lblIMEI.AutoSize = true;
            this.lblIMEI.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblIMEI.Location = new System.Drawing.Point(31, 343);
            this.lblIMEI.Name = "lblIMEI";
            this.lblIMEI.Size = new System.Drawing.Size(49, 21);
            this.lblIMEI.TabIndex = 7;
            this.lblIMEI.Text = "IMEI";
            this.lblIMEI.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblScreenID
            // 
            this.lblScreenID.AutoSize = true;
            this.lblScreenID.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblScreenID.Location = new System.Drawing.Point(31, 314);
            this.lblScreenID.Name = "lblScreenID";
            this.lblScreenID.Size = new System.Drawing.Size(85, 21);
            this.lblScreenID.TabIndex = 6;
            this.lblScreenID.Text = "Screen ID";
            this.lblScreenID.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblCameraID
            // 
            this.lblCameraID.AutoSize = true;
            this.lblCameraID.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblCameraID.Location = new System.Drawing.Point(31, 285);
            this.lblCameraID.Name = "lblCameraID";
            this.lblCameraID.Size = new System.Drawing.Size(91, 21);
            this.lblCameraID.TabIndex = 5;
            this.lblCameraID.Text = "Camera ID";
            this.lblCameraID.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblBatteryID
            // 
            this.lblBatteryID.AutoSize = true;
            this.lblBatteryID.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblBatteryID.Location = new System.Drawing.Point(31, 256);
            this.lblBatteryID.Name = "lblBatteryID";
            this.lblBatteryID.Size = new System.Drawing.Size(87, 21);
            this.lblBatteryID.TabIndex = 4;
            this.lblBatteryID.Text = "Battery ID";
            this.lblBatteryID.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblProcessorID
            // 
            this.lblProcessorID.AutoSize = true;
            this.lblProcessorID.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblProcessorID.Location = new System.Drawing.Point(31, 228);
            this.lblProcessorID.Name = "lblProcessorID";
            this.lblProcessorID.Size = new System.Drawing.Size(110, 21);
            this.lblProcessorID.TabIndex = 3;
            this.lblProcessorID.Text = "Processor ID";
            this.lblProcessorID.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblOperationSystem
            // 
            this.lblOperationSystem.AutoSize = true;
            this.lblOperationSystem.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblOperationSystem.Location = new System.Drawing.Point(31, 198);
            this.lblOperationSystem.Name = "lblOperationSystem";
            this.lblOperationSystem.Size = new System.Drawing.Size(144, 21);
            this.lblOperationSystem.TabIndex = 2;
            this.lblOperationSystem.Text = "Operation System";
            this.lblOperationSystem.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblModel
            // 
            this.lblModel.AutoSize = true;
            this.lblModel.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblModel.Location = new System.Drawing.Point(31, 169);
            this.lblModel.Name = "lblModel";
            this.lblModel.Size = new System.Drawing.Size(58, 21);
            this.lblModel.TabIndex = 1;
            this.lblModel.Text = "Model";
            this.lblModel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblBrandName
            // 
            this.lblBrandName.AutoSize = true;
            this.lblBrandName.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblBrandName.Location = new System.Drawing.Point(31, 140);
            this.lblBrandName.Name = "lblBrandName";
            this.lblBrandName.Size = new System.Drawing.Size(103, 21);
            this.lblBrandName.TabIndex = 0;
            this.lblBrandName.Text = "Brand Name";
            this.lblBrandName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "SmartPhones Components";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPageBattery.ResumeLayout(false);
            this.tabPageBattery.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewBattery)).EndInit();
            this.tabPageCamera.ResumeLayout(false);
            this.tabPageCamera.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewCamera)).EndInit();
            this.tabPageProcessor.ResumeLayout(false);
            this.tabPageProcessor.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewProcessor)).EndInit();
            this.tabPageScreen.ResumeLayout(false);
            this.tabPageScreen.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewScreen)).EndInit();
            this.tabPageSmartPhones.ResumeLayout(false);
            this.tabPageSmartPhones.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSmartphones)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPageBattery;
        private System.Windows.Forms.Label lblBatteryType;
        private System.Windows.Forms.TabPage tabPageCamera;
        private System.Windows.Forms.Button btnSaveBattery;
        private System.Windows.Forms.Button btnDeleteBattery;
        private System.Windows.Forms.Button btnUpdateBattery;
        private System.Windows.Forms.Button btnInsertBattery;
        private System.Windows.Forms.DataGridView dataGridViewBattery;
        private System.Windows.Forms.Label lblBatteryCapacity;
        private System.Windows.Forms.TextBox txtBatteryCapacity;
        private System.Windows.Forms.TextBox txtBatteryType;
        private System.Windows.Forms.Button btnSaveCamera;
        private System.Windows.Forms.Button btnDeleteCamera;
        private System.Windows.Forms.Button btnUpdateCamera;
        private System.Windows.Forms.Button btnInsertCamera;
        private System.Windows.Forms.DataGridView dataGridViewCamera;
        private System.Windows.Forms.TextBox txtBoxRearCamera;
        private System.Windows.Forms.TextBox txtBoxFrontCamera;
        private System.Windows.Forms.Label lblRearCamera;
        private System.Windows.Forms.Label lblFrontCamera;
        private System.Windows.Forms.TabPage tabPageProcessor;
        private System.Windows.Forms.Button btnSaveProcessor;
        private System.Windows.Forms.Button btnDeleteProcessor;
        private System.Windows.Forms.Button btnUpdateProcessor;
        private System.Windows.Forms.Button btnInsertProcessor;
        private System.Windows.Forms.DataGridView dataGridViewProcessor;
        private System.Windows.Forms.TextBox txtBoxRAM;
        private System.Windows.Forms.TextBox txtBoxFrequance;
        private System.Windows.Forms.TextBox txtBoxNameProcessor;
        private System.Windows.Forms.Label lblRamProcessor;
        private System.Windows.Forms.Label lblFrequanceProcessor;
        private System.Windows.Forms.Label lblNameProcessor;
        private System.Windows.Forms.TabPage tabPageScreen;
        private System.Windows.Forms.Label lblDisplayType;
        private System.Windows.Forms.Label lblRefreshRate;
        private System.Windows.Forms.Label lblDisplayResolution;
        private System.Windows.Forms.Label lblScreenSize;
        private System.Windows.Forms.Button btnSaveScreen;
        private System.Windows.Forms.Button btnDeleteScreen;
        private System.Windows.Forms.Button btnUpdateScreen;
        private System.Windows.Forms.Button btnInsertScreen;
        private System.Windows.Forms.DataGridView dataGridViewScreen;
        private System.Windows.Forms.TextBox txtBoxDisplayType;
        private System.Windows.Forms.TextBox txtBoxRefreshRate;
        private System.Windows.Forms.TextBox txtBoxDisplayResolution;
        private System.Windows.Forms.TextBox txtBoxScreenSize;
        private System.Windows.Forms.TabPage tabPageSmartPhones;
        private System.Windows.Forms.Label lblBatteryID;
        private System.Windows.Forms.Label lblProcessorID;
        private System.Windows.Forms.Label lblOperationSystem;
        private System.Windows.Forms.Label lblModel;
        private System.Windows.Forms.Label lblBrandName;
        private System.Windows.Forms.Label lblIMEI;
        private System.Windows.Forms.Label lblScreenID;
        private System.Windows.Forms.Label lblCameraID;
        private System.Windows.Forms.DataGridView dataGridViewSmartphones;
        private System.Windows.Forms.TextBox txtBoxProcessorID;
        private System.Windows.Forms.TextBox txtBoxOS;
        private System.Windows.Forms.TextBox txtBoxModel;
        private System.Windows.Forms.TextBox txtBoxBrandName;
        private System.Windows.Forms.TextBox txtBoxIMEI;
        private System.Windows.Forms.TextBox txtBoxScreenID;
        private System.Windows.Forms.TextBox txtBoxCameraID;
        private System.Windows.Forms.TextBox txtBoxBatteryID;
        private System.Windows.Forms.Label lblTittle;
        private System.Windows.Forms.Label lblTitleCamera;
        private System.Windows.Forms.Label lblTitleProcessors;
        private System.Windows.Forms.Label lblScreen;
        private System.Windows.Forms.Label lblTitleSmartPhones;
        private System.Windows.Forms.Button btnSaveSmartPhone;
        private System.Windows.Forms.Button btnDeleteSmartPhone;
        private System.Windows.Forms.Button btnUpdateSmartPhone;
        private System.Windows.Forms.Button btnInsertSmartPhone;
        private System.Windows.Forms.DateTimePicker dateTimePickerSmartPhone;
    }
}

