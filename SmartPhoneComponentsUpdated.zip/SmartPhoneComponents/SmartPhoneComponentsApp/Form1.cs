﻿using Controller;
using Data.Entyties;
using SmartPhoneComponentsApp;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SmartPhoneComponentsApp
{
    public partial class Form1 : Form
    {
        private PhoneController controller = new PhoneController();
        private int editId = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            UpdateBatteryGrid();
            UpdateCameraGrid();
            UpdateDisplayGrid();
            UpdateProcessorGrid();
            UpdateSmartPhonesGrid();
        }

        //Battery SIDE
        private Battery GetEditedBattery()
        {
            Battery battery = new Battery();
            battery.Id = editId;

            var batteryType = txtBatteryType.Text;
            int batteryCapacity = 0;
            int.TryParse(txtBatteryCapacity.Text, out batteryCapacity);

            battery.Battery_Type = batteryType;
            battery.Battery_Capacity = batteryCapacity;

            return battery;
        }

        private void ResetSelectBattery()
        {
            dataGridViewBattery.ClearSelection();
            dataGridViewBattery.Enabled = true;
        }

        private void UpdateBatteryGrid()
        {
            dataGridViewBattery.DataSource = controller.batteryController.GetAll();
            dataGridViewBattery.ReadOnly = true;
            dataGridViewBattery.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        }

        private void ClearBatteryTextBoxes()
        {
            txtBatteryType.Text = "";
            txtBatteryCapacity.Text = "0";
        }

        private void UpdateBatteryTextBoxes(int id)
        {
            Battery update = controller.batteryController.GetId(id);
            txtBatteryType.Text = update.Battery_Type;
            txtBatteryCapacity.Text = update.Battery_Capacity.ToString();
        }

        private void ToggleSaveUpdateBattery()
        {
            if (btnUpdateBattery.Visible)
            {
                btnSaveBattery.Visible = true;
                btnUpdateBattery.Visible = false;
            }
            else
            {
                btnSaveBattery.Visible = false;
                btnUpdateBattery.Visible = true;
            }
        }

        private void DisableSelectBattery()
        {
            dataGridViewBattery.Enabled = false;
        }

        private void btnInsertBattery_Click(object sender, EventArgs e)
        {
            var batteryType = txtBatteryType.Text;
            int batteryCapacity = 0;
            int.TryParse(txtBatteryCapacity.Text, out batteryCapacity);

            Battery battery = new Battery();
            battery.Battery_Type = batteryType;
            battery.Battery_Capacity = batteryCapacity;

            controller.batteryController.Add(battery);
            UpdateBatteryGrid();
            ClearBatteryTextBoxes();
        }

        private void btnSaveBattery_Click(object sender, EventArgs e)
        {
            Battery editedBattery = GetEditedBattery();
            controller.batteryController.Update(editedBattery);
            UpdateBatteryGrid();
            ResetSelectBattery();
            ToggleSaveUpdateBattery();
            ClearBatteryTextBoxes();
        }

        private void btnDeleteBattery_Click(object sender, EventArgs e)
        {
            if (dataGridViewBattery.SelectedRows.Count > 0)
            {
                var item = dataGridViewBattery.SelectedRows[0].Cells;
                var id = int.Parse(item[0].Value.ToString());
                controller.batteryController.Delete(id);
                UpdateBatteryGrid();
                ResetSelectBattery();
            }
        }

        private void btnUpdateBattery_Click(object sender, EventArgs e)
        {
            if (dataGridViewBattery.SelectedRows.Count > 0)
            {
                var item = dataGridViewBattery.SelectedRows[0].Cells;
                var id = int.Parse(item[0].Value.ToString());
                editId = id;
                UpdateBatteryTextBoxes(id);
                ToggleSaveUpdateBattery();
                DisableSelectBattery();
            }
        }

        //Camera SIDE
        private Camera GetEditedCamera()
        {
            Camera camera = new Camera();
            camera.Id = editId;

            int frontCamera = 0;
            int.TryParse(txtBoxFrontCamera.Text, out frontCamera);
            int rearCamera = 0;
            int.TryParse(txtBoxRearCamera.Text, out rearCamera);

            camera.Front_Camera = frontCamera;
            camera.Rear_Camera = rearCamera;

            return camera;
        }

        private void ResetSelectCamera()
        {
            dataGridViewCamera.ClearSelection();
            dataGridViewCamera.Enabled = true;
        }

        private void UpdateCameraGrid()
        {
            dataGridViewCamera.DataSource = controller.cameraController.GetAll();
            dataGridViewCamera.ReadOnly = true;
            dataGridViewCamera.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        }

        private void ClearCameraTextBoxes()
        {
            txtBoxFrontCamera.Text = "0";
            txtBoxRearCamera.Text = "0";
        }

        private void UpdateCameraTextBoxes(int id)
        {
            Camera update = controller.cameraController.GetId(id);
            txtBoxFrontCamera.Text = update.Front_Camera.ToString();
            txtBoxRearCamera.Text = update.Rear_Camera.ToString();
        }

        private void ToggleSaveUpdateCamera()
        {
            if (btnUpdateCamera.Visible)
            {
                btnSaveCamera.Visible = true;
                btnUpdateCamera.Visible = false;
            }
            else
            {
                btnSaveCamera.Visible = false;
                btnUpdateCamera.Visible = true;
            }
        }

        private void DisableSelectCamera()
        {
            dataGridViewCamera.Enabled = false;
        }

        private void btnInsertCamera_Click(object sender, EventArgs e)
        {
            int frontCamera = 0;
            int.TryParse(txtBoxFrontCamera.Text, out frontCamera);
            int rearCamera = 0;
            int.TryParse(txtBoxRearCamera.Text, out rearCamera);

            Camera camera = new Camera();
            camera.Front_Camera = frontCamera;
            camera.Front_Camera = frontCamera;

            controller.cameraController.Add(camera);
            UpdateCameraGrid();
            ClearCameraTextBoxes();
        }

        private void btnUpdateCamera_Click(object sender, EventArgs e)
        {
            if (dataGridViewCamera.SelectedRows.Count > 0)
            {
                var item = dataGridViewCamera.SelectedRows[0].Cells;
                var id = int.Parse(item[0].Value.ToString());
                editId = id;
                UpdateCameraTextBoxes(id);
                ToggleSaveUpdateCamera();
                DisableSelectCamera();
            }
        }

        private void btnDeleteCamera_Click(object sender, EventArgs e)
        {
            if (dataGridViewCamera.SelectedRows.Count > 0)
            {
                var item = dataGridViewCamera.SelectedRows[0].Cells;
                var id = int.Parse(item[0].Value.ToString());
                controller.cameraController.Delete(id);
                UpdateCameraGrid();
                ResetSelectCamera();
            }
        }

        private void btnSaveCamera_Click(object sender, EventArgs e)
        {
            Camera editedCamera = GetEditedCamera();
            controller.cameraController.Update(editedCamera);
            UpdateCameraGrid();
            ResetSelectCamera();
            ToggleSaveUpdateCamera();
            ClearCameraTextBoxes();
        }
        //Processor Side
        private Processor GetEditedProcessor()
        {
            Processor processor = new Processor();
            processor.Id = editId;

            var name = txtBoxNameProcessor.Text;
            double frequance = 0;
            double.TryParse(txtBoxFrequance.Text, out frequance);
            int ram = 0;
            int.TryParse(txtBoxRAM.Text, out ram);

            processor.Name = name;
            processor.Frequance = frequance;
            processor.Ram = ram;

            return processor;
        }

        private void ResetSelectProcessor()
        {
            dataGridViewProcessor.ClearSelection();
            dataGridViewProcessor.Enabled = true;
        }

        private void UpdateProcessorGrid()
        {
            dataGridViewProcessor.DataSource = controller.processorController.GetAll();
            dataGridViewProcessor.ReadOnly = true;
            dataGridViewProcessor.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        }

        private void ClearProcessorTextBoxes()
        {
            txtBoxNameProcessor.Text = " ";
            txtBoxFrequance.Text = "0.00";
            txtBoxRAM.Text = "0";
        }

        private void UpdateProcessorTextBoxes(int id)
        {
            Processor update = controller.processorController.GetId(id);
            txtBoxNameProcessor.Text = update.Name;
            txtBoxFrequance.Text = update.Frequance.ToString();
            txtBoxRAM.Text = update.Ram.ToString();
        }

        private void ToggleSaveUpdateProcessor()
        {
            if (btnUpdateProcessor.Visible)
            {
                btnSaveProcessor.Visible = true;
                btnUpdateProcessor.Visible = false;
            }
            else
            {
                btnSaveProcessor.Visible = false;
                btnUpdateProcessor.Visible = true;
            }
        }

        private void DisableSelectProcessor()
        {
            dataGridViewProcessor.Enabled = false;
        }

        private void btnInsertProcessor_Click(object sender, EventArgs e)
        {
            var name = txtBoxNameProcessor.Text;
            double frequance = 0;
            double.TryParse(txtBoxFrequance.Text, out frequance);
            int ram = 0;
            int.TryParse(txtBoxRAM.Text, out ram);

            Processor processor = new Processor();
            processor.Name = name;
            processor.Frequance = frequance;
            processor.Ram = ram;

            controller.processorController.Add(processor);
            UpdateProcessorGrid();
            ClearProcessorTextBoxes();
        }

        private void btnUpdateProcessor_Click(object sender, EventArgs e)
        {
            if (dataGridViewProcessor.SelectedRows.Count > 0)
            {
                var item = dataGridViewProcessor.SelectedRows[0].Cells;
                var id = int.Parse(item[0].Value.ToString());
                editId = id;
                UpdateProcessorTextBoxes(id);
                ToggleSaveUpdateProcessor();
                DisableSelectProcessor();
            }
        }

        private void btnDeleteProcessor_Click(object sender, EventArgs e)
        {
            if (dataGridViewProcessor.SelectedRows.Count > 0)
            {
                var item = dataGridViewProcessor.SelectedRows[0].Cells;
                var id = int.Parse(item[0].Value.ToString());
                controller.processorController.Delete(id);
                UpdateProcessorGrid();
                ResetSelectProcessor();
            }
        }

        private void btnSaveProcessor_Click(object sender, EventArgs e)
        {
            Processor editedProcessor = GetEditedProcessor();
            controller.processorController.Update(editedProcessor);
            UpdateProcessorGrid();
            ResetSelectProcessor();
            ToggleSaveUpdateProcessor();
            ClearProcessorTextBoxes();
        }
        //Screen Side
        private Display GetEditedDisplay()
        {
            Display display = new Display();
            display.Id = editId;

            double screenSize = 0;
            double.TryParse(txtBoxScreenSize.Text, out screenSize);
            int refreshRate = 0;
            int.TryParse(txtBoxRefreshRate.Text, out refreshRate);
            var displayType = txtBoxDisplayType.Text;
            var displayResolution = txtBoxDisplayResolution.Text;

            display.Display_Resolution = displayResolution;
            display.Display_Type = displayType;
            display.Screen_Size = screenSize;
            display.Refresh_Rate = refreshRate;

            return display;
        }

        private void ResetSelectDisplay()
        {
            dataGridViewScreen.ClearSelection();
            dataGridViewScreen.Enabled = true;
        }

        private void UpdateDisplayGrid()
        {
            dataGridViewScreen.DataSource = controller.screenController.GetAll();
            dataGridViewScreen.ReadOnly = true;
            dataGridViewScreen.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        }

        private void ClearDisplayTextBoxes()
        {
            txtBoxDisplayResolution.Text = " ";
            txtBoxDisplayType.Text = " ";
            txtBoxRefreshRate.Text = "0";
            txtBoxScreenSize.Text = "0.00";
        }

        private void UpdateDisplayTextBoxes(int id)
        {
            Display update = controller.screenController.GetId(id);
            txtBoxDisplayResolution.Text = update.Display_Resolution;
            txtBoxDisplayType.Text = update.Display_Type;
            txtBoxRefreshRate.Text = update.Refresh_Rate.ToString();
            txtBoxScreenSize.Text = update.Screen_Size.ToString();
        }

        private void ToggleSaveUpdateDisplay()
        {
            if (btnUpdateScreen.Visible)
            {
                btnSaveScreen.Visible = true;
                btnUpdateScreen.Visible = false;
            }
            else
            {
                btnSaveScreen.Visible = false;
                btnUpdateScreen.Visible = true;
            }
        }

        private void DisableSelectDisplay()
        {
            dataGridViewScreen.Enabled = false;
        }

        private void btnInsertScreen_Click(object sender, EventArgs e)
        {
            double screenSize = 0;
            double.TryParse(txtBoxScreenSize.Text, out screenSize);
            var displayResolution = txtBoxDisplayResolution.Text;
            int refreshRate = 0;
            int.TryParse(txtBoxRefreshRate.Text, out refreshRate);
            var displayType = txtBoxDisplayType.Text;

            Display display = new Display();
            display.Screen_Size = screenSize;
            display.Display_Resolution = displayResolution;
            display.Refresh_Rate = refreshRate;
            display.Display_Type = displayType;

            controller.screenController.Add(display);
            UpdateDisplayGrid();
            ClearDisplayTextBoxes();
        }

        private void btnUpdateScreen_Click(object sender, EventArgs e)
        {
            if (dataGridViewScreen.SelectedRows.Count > 0)
            {
                var item = dataGridViewScreen.SelectedRows[0].Cells;
                var id = int.Parse(item[0].Value.ToString());
                editId = id;
                UpdateDisplayTextBoxes(id);
                ToggleSaveUpdateDisplay();
                DisableSelectDisplay();
            }
        }

        private void btnDeleteScreen_Click(object sender, EventArgs e)
        {
            if (dataGridViewScreen.SelectedRows.Count > 0)
            {
                var item = dataGridViewScreen.SelectedRows[0].Cells;
                var id = int.Parse(item[0].Value.ToString());
                controller.screenController.Delete(id);
                UpdateDisplayGrid();
                ResetSelectDisplay();
            }
        }

        private void btnSaveScreen_Click(object sender, EventArgs e)
        {
            Display editedDisplay = GetEditedDisplay();
            controller.screenController.Update(editedDisplay);
            UpdateDisplayGrid();
            ResetSelectDisplay();
            ToggleSaveUpdateDisplay();
            ClearDisplayTextBoxes();
        }
        //smartphones Side
        private SmartPhone GetEditedSmartPhone()
        {
            SmartPhone smartPhone = new SmartPhone();
            smartPhone.Id = editId;

            var brandName = txtBoxBrandName.Text;
            var model = txtBoxModel.Text;
            var os = txtBoxOS.Text;
            int processorId = 0;
            int.TryParse(txtBoxProcessorID.Text, out processorId);
            int batteryId = 0;
            int.TryParse(txtBoxBatteryID.Text, out batteryId);
            int cameraId = 0;
            int.TryParse(txtBoxCameraID.Text, out cameraId);
            int screenId = 0;
            int.TryParse(txtBoxScreenID.Text, out screenId);
            var Imei = txtBoxIMEI.Text;
            var data = dateTimePickerSmartPhone.Value;


            smartPhone.Brand_Name = brandName;
            smartPhone.Model = model;
            smartPhone.Operation_System = os;
            smartPhone.Processor_Id = processorId;
            smartPhone.Battery_Id = batteryId;
            smartPhone.Camera_Id = cameraId;
            smartPhone.Screen_Id = screenId;
            smartPhone.Release_Date = data;

            return smartPhone;
        }

        private void ResetSelectSmartPhones()
        {
            dataGridViewSmartphones.ClearSelection();
            dataGridViewSmartphones.Enabled = true;
        }

        private void UpdateSmartPhonesGrid()
        {
            dataGridViewSmartphones.DataSource = controller.smartPhoneController.GetAll();
            dataGridViewSmartphones.ReadOnly = true;
            dataGridViewSmartphones.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        }

        private void ClearSmartPhonesTextBoxes()
        {
            txtBoxBrandName.Text = " ";
            txtBoxModel.Text = " ";
            txtBoxOS.Text = " ";
            txtBoxProcessorID.Text = "0";
            txtBoxBatteryID.Text = "0";
            txtBoxCameraID.Text = "0";
            txtBoxScreenID.Text = "0";
            txtBoxIMEI.Text = " ";
            //pictureBoxSmartPhones.Image = null;
            
        }

        private void UpdateSmartPhonesTextBoxes(int id)
        {
            SmartPhone update = controller.smartPhoneController.GetId(id);

            txtBoxBrandName.Text = update.Brand_Name;
            txtBoxModel.Text = update.Model;
            txtBoxOS.Text = update.Operation_System;
            txtBoxProcessorID.Text = update.Processor_Id.ToString();
            txtBoxBatteryID.Text = update.Battery_Id.ToString();
            txtBoxCameraID.Text = update.Camera_Id.ToString();
            txtBoxScreenID.Text = update.Screen_Id.ToString();
            txtBoxIMEI.Text = update.Imei.ToString();
            dateTimePickerSmartPhone.Value = (DateTime)update.Release_Date;
            //pictureBoxSmartPhones.Image = update.Picture;
        }

        private void ToggleSaveUpdateSmartPhone()
        {
            if (btnUpdateSmartPhone.Visible)
            {
                btnSaveSmartPhone.Visible = true;
                btnUpdateSmartPhone.Visible = false;
            }
            else
            {
                btnSaveSmartPhone.Visible = false;
                btnUpdateSmartPhone.Visible = true;
            }
        }

        private void DisableSelectSmartPhone()
        {
            dataGridViewSmartphones.Enabled = false;
        }

        private void btnInsertSmartPhone_Click(object sender, EventArgs e)
        {
            var brandName = txtBoxBrandName.Text;
            var model = txtBoxModel.Text;
            var oS = txtBoxOS.Text;
            int processorId = 0;
            int.TryParse(txtBoxProcessorID.Text, out processorId);
            int batteryID = 0;
            int.TryParse(txtBoxBatteryID.Text, out batteryID);
            int cameraID = 0;
            int.TryParse(txtBoxCameraID.Text, out cameraID);
            int screenID = 0;
            int.TryParse(txtBoxScreenID.Text, out screenID);
            var Imei = txtBoxIMEI.Text;
            var data = dateTimePickerSmartPhone.Value;

            SmartPhone smartPhone = new SmartPhone();
            smartPhone.Brand_Name = brandName;
            smartPhone.Model = model;
            smartPhone.Operation_System = oS;
            smartPhone.Processor_Id = processorId;
            smartPhone.Battery_Id = batteryID;
            smartPhone.Camera_Id = cameraID;
            smartPhone.Screen_Id = screenID;
            smartPhone.Imei = char.Parse(Imei);
            smartPhone.Release_Date = data;

            controller.smartPhoneController.Add(smartPhone);
            UpdateSmartPhonesGrid();
            ClearSmartPhonesTextBoxes();
        }

        private void btnUpdateSmartPhone_Click(object sender, EventArgs e)
        {
            if (dataGridViewSmartphones.SelectedRows.Count > 0)
            {
                var item = dataGridViewSmartphones.SelectedRows[0].Cells;
                var id = int.Parse(item[0].Value.ToString());
                editId = id;
                UpdateSmartPhonesTextBoxes(id);
                ToggleSaveUpdateSmartPhone();
                DisableSelectSmartPhone();
            }
        }

        private void btnDeleteSmartPhone_Click(object sender, EventArgs e)
        {
            if (dataGridViewSmartphones.SelectedRows.Count > 0)
            {
                var item = dataGridViewSmartphones.SelectedRows[0].Cells;
                var id = int.Parse(item[0].Value.ToString());
                controller.smartPhoneController.Delete(id);
                UpdateSmartPhonesGrid();
                ResetSelectSmartPhones();
            }
        }

        private void btnSaveSmartPhone_Click(object sender, EventArgs e)
        {
            SmartPhone editedSmartPhone = GetEditedSmartPhone();
            controller.smartPhoneController.Update(editedSmartPhone);
            UpdateSmartPhonesGrid();
            ResetSelectSmartPhones();
            ToggleSaveUpdateSmartPhone();
            ClearSmartPhonesTextBoxes();
        }
    }
}
