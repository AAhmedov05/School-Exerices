﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data.Entyties
{
    public class Display
    {
        [Key]
        public int Id { get; set; }
        [Required]
        public double Screen_Size { get; set; }
        [StringLength(9)]
        public string Display_Resolution { get; set; }
        public int Refresh_Rate { get; set; }
        [StringLength(10)]
        public string Display_Type { get; set; }
        public ICollection<SmartPhone> SmartPhones { get; set; }
    }
}
