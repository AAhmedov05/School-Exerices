﻿using Buisness.Controller_Entyties;
using System;

namespace Controller
{
    public class PhoneController
    {
        public SmartPhoneController smartPhoneController = new SmartPhoneController();
        public ProcessorController processorController = new ProcessorController();
        public BatteryController batteryController = new BatteryController();
        public ScreenController screenController = new ScreenController();
        public CameraController cameraController = new CameraController();
    }
}
