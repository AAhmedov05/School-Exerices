﻿using Controller.Repository;
using Data;
using Data.Entyties;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Buisness.Controller_Entyties
{
        public class SmartPhoneController : ICRUD_Methods<SmartPhone>
        {
            private PhoneContext context;
            public void Add(SmartPhone item)
            {
                using (context = new PhoneContext())
                {
                    context.SmartPhones.Add(item);
                    context.SaveChanges();
                }
            }

            public void Delete(int id)
            {
                using (context = new PhoneContext())
                {
                    var phone = context.SmartPhones.Find(id);
                    if (phone != null)
                    {
                        context.SmartPhones.Remove(phone);
                        context.SaveChanges();
                    }
                }
            }

            public List<SmartPhone> GetAll()
            {
                using (context = new PhoneContext())
                {
                    return context.SmartPhones.ToList();
                }
            }

            public SmartPhone GetId(int id)
            {
                using (context = new PhoneContext())
                {
                    return context.SmartPhones.Find(id);
                }
            }

            public void Update(SmartPhone item)
            {
                using (context = new PhoneContext())
                {
                    var phone = context.SmartPhones.Find(item.Id);
                    if (phone != null)
                    {
                        context.Entry(phone).CurrentValues.SetValues(item);
                        context.SaveChanges();
                    }
                }
            }
        }
}