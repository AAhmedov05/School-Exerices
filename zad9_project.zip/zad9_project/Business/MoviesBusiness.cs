﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DI_T7_zad.Business
{
    public class MoviesBusiness
    {
        private MoviesContext moviesContext;
        public List<Category> GetAllCategories()
        {
            using (moviesContext = new MoviesContext())
            {
                return moviesContext.Categories.ToList();
            }
        }
        public Category GetCategories(int id)
        {
            using (moviesContext = new MoviesContext())
            {
                return moviesContext.Categories.Find(id);

            }
        }

        public void AddCategories(Category category)
        {
            using (moviesContext = new MoviesContext())
            {
                moviesContext.Categories.Add(category);
                moviesContext.SaveChanges();

            }
        }

        public void UpdateCategories(Category category)
        {
            using (moviesContext = new MoviesContext())
            {

                var item = moviesContext.Categories.Find(category.ID);
                if (item != null)
                {
                    moviesContext.Entry(item).CurrentValues.SetValues(category);
                    moviesContext.SaveChanges();
                }

            }
        }

        public void DeleteCategories(int id)
        {
            using (moviesContext = new MoviesContext())
            {
                var category = moviesContext.Categories.Find(id);
                if (category != null)
                {
                    moviesContext.Categories.Remove(category);
                    moviesContext.SaveChanges();
                }
            }
        }
    }
}
