﻿using DI_T7_zad.Business;

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PresentationWindowsForm
{
    public partial class Form1 : Form
    {
        private MoviesBusiness moviesBusiness = new MoviesBusiness();
        private int editId = 0;
        public Form1()
        {
            InitializeComponent();
        }
        private void UpdateGrid()
        {
            dataGridView1.DataSource = moviesBusiness.GetAllCategories();
            dataGridView1.ReadOnly = true;
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        }
        private void ClearTextBoxes()
        {
            txtCategoryName.Text = "";
            txtNotes.Text = "";
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            UpdateGrid();
            ClearTextBoxes();
        }
        private void btnInsert_Click(object sender, EventArgs e)
        {
            Category category = new Category();
            category.Category_name = txtCategoryName.Text;
            category.Notes = txtNotes.Text;
            
            UpdateGrid();
            ClearTextBoxes();
        }


        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                var item = dataGridView1.SelectedRows[0].Cells;
                var id = int.Parse(item[0].Value.ToString());
                editId = id;
                UpdateTextboxes(id);
                ToggleSaveUpdate();
                DisableSelect();
            }
        }

        private void ToggleSaveUpdate()
        {
            if (btnUpdate.Visible)
            {
                btnSave.Visible = true;
                btnUpdate.Visible = false;
            }
            else
            {
                btnSave.Visible = false;
                btnUpdate.Visible = true;
            }
        }

        private void UpdateTextboxes(int id)
        {
            Category update = moviesBusiness.GetCategories(id);
            txtCategoryName.Text = update.Category_name;
            txtNotes.Text = update.Notes;

        }

        private void DisableSelect()
        {
            dataGridView1.Enabled = false;
        }

        private void ResetSelect()
        {
            dataGridView1.ClearSelection();
            dataGridView1.Enabled = true;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            Category editedCategory = GetEditedCategory();
            
            UpdateGrid();
            ResetSelect();
            ToggleSaveUpdate();
        }

        private Category GetEditedCategory()
        {
            Category category = new Category();
            category.ID = editId;
            category.Category_name = txtCategoryName.Text;
            category.Notes = txtNotes.Text;
            return category;
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                var item = dataGridView1.SelectedRows[0].Cells;
                var id = int.Parse(item[0].Value.ToString());
              
                UpdateGrid();
                ResetSelect();
            }
        }

    }
}
