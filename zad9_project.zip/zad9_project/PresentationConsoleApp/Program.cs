﻿using DI_T7_zad.Presentation;//добавяне
using System;

namespace PresentationConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {

            Display display = new Display();

        }
    }
}
