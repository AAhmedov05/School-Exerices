﻿using DI_T7_zad.Business;
using System;
using System.Collections.Generic;
using System.Text;

namespace DI_T7_zad.Presentation
{
   public class Display
    {
        private MoviesBusiness moviesBusiness = new MoviesBusiness();
        public Display()
        {
            var movies = moviesBusiness.GetAllCategories();

            foreach (var item in movies)
            {
               Console.WriteLine("{0} {1} ", item.ID, item.Category_name);
            }
        }
    }
}
