﻿using Data.Model;//добавяне
using Microsoft.EntityFrameworkCore;//добавяне
using System;
using System.Collections.Generic;
using System.Text;

namespace DI_T7_zad.Data
{
   public class MoviesContext : DbContext
    {      

       public MoviesContext()
        {
            Database.EnsureCreated();
        }
     
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {          
            optionsBuilder.UseSqlServer(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=MovieDB;");
        }
        public DbSet<Movie> Movies { get; set; }
        public DbSet<Director> Directors { get; set; }
        public DbSet<Genre> Genres { get; set; }
        public DbSet<Category> Categories { get; set; }
    }
}
