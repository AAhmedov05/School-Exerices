﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Data.Model
{
    public class Movie
    {
        [Key]
        public int ID { get; set; }
        [StringLength(50)]
        public string? Title { get; set; }
        public DateTime? CopyRight_Year { get; set; }
        public DateTime? Lenght { get; set; }
        public int? Raiting { get; set; }

        [DataType(DataType.Text)]
        public string? Notes { get; set; }
        public Director Director { get; set; }
        public Genre Genre { get; set; }
        public Category Category { get; set; }
    }
}
