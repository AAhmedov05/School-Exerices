﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using System.Text;

namespace Data.Model
{
    public class Director
    {
        [Key]
        public int ID { get; set; }
        [StringLength(50)]
        public string? Director_Name { get; set; }
        [DataType(DataType.Text)]
        public string? Notes { get; set; }
        [StringLength(50)]
        public string? Alias { get; set; }
        public List<Movie> Movies { get; set; }

    }
}
