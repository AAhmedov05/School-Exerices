﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Data.Model
{
    public class Genre
    {
        [Key]
        public int ID { get; set; }
        [StringLength(50)]
        public string? Genre_Name { get; set; }
        [DataType(DataType.Text)]
        public string? Notes { get; set; }
        public List<Movie> Movies { get; set; }
    }
}
