﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace EventuresWeb.Data.Migrations
{
    public partial class SecondInitialMigration : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
