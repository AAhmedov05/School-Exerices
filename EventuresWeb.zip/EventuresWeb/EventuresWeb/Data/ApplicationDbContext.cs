﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;
using EventuresWeb.Models;

namespace EventuresWeb.Data
{
    public class ApplicationDbContext : IdentityDbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }
        public DbSet<EventuresWeb.Models.Event> Event { get; set; }
        public DbSet<EventuresWeb.Models.Order> Order { get; set; }
    }
}
