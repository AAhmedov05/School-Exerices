﻿using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace EventuresWeb.Models
{
    public class Order
    {
        [Key]
        public Guid Id { get; set; }
        public DateTime OrderedOn { get; set; }
        public IdentityUser Customer { get; set; }
        public int TicketsCount { get; set; }
        [ForeignKey(nameof(Event))]
        public Event Events { get; set; }
    }
}
