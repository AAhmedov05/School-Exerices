﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EventuresWeb.Models
{
    public class EventView
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public DateTime Start { get; set; }
        public DateTime End { get; set; }
        public Order Order { get; set; }
        public ICollection<Order> Orders { get; set; } = new List<Order>();
    }
}
