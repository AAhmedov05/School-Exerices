﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace BarberWeb.Migrations
{
    public partial class InitialMigration : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Client_Barber_Clients",
                table: "Client");

            migrationBuilder.DropIndex(
                name: "IX_Client_Clients",
                table: "Client");

            migrationBuilder.DropColumn(
                name: "Clients",
                table: "Client");

            migrationBuilder.AddColumn<int>(
                name: "BarberId",
                table: "Client",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Client_BarberId",
                table: "Client",
                column: "BarberId");

            migrationBuilder.AddForeignKey(
                name: "FK_Client_Barber_BarberId",
                table: "Client",
                column: "BarberId",
                principalTable: "Barber",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Client_Barber_BarberId",
                table: "Client");

            migrationBuilder.DropIndex(
                name: "IX_Client_BarberId",
                table: "Client");

            migrationBuilder.DropColumn(
                name: "BarberId",
                table: "Client");

            migrationBuilder.AddColumn<int>(
                name: "Clients",
                table: "Client",
                type: "int",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Client_Clients",
                table: "Client",
                column: "Clients");

            migrationBuilder.AddForeignKey(
                name: "FK_Client_Barber_Clients",
                table: "Client",
                column: "Clients",
                principalTable: "Barber",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
