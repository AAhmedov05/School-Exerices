﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BarberWeb.Models
{
    public class FadeTypes
    {
        public enum Fades
        {
                high_fade,
                mid_fade, 
                low_fade, 
                temple_fade,
                burst_fade,
                skin_fade, 
                drop_fade,
                shadow_fade
        }
    }
}
