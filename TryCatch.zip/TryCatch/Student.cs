﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TryCatch
{
    class Student
    {
        private string clas;
        private int id;
        private string name;
        private int bel;
        private int math;

        public string Clas
        {
            get { return this.clas; }
            set
            {
                if (string.IsNullOrEmpty(value))
                {
                    throw new ArgumentNullException("Clas cannot be empty");
                }

                this.clas = value;
            }
        }

        public int Id
        {
            get { return this.id; }
            set
            {
                if (value < 0 || value > 26)
                {
                    throw new ArgumentOutOfRangeException("ID must be between 1 and 26");
                }

                this.id = value;
            }
        }

        public string Name
        {
            get { return this.name; }
            set
            {
                if (string.IsNullOrEmpty(value))
                {
                    throw new ArgumentNullException("Name cannot be empty");
                }

                this.name = value;
            }
        }

        public int Bel
        {
            get { return this.bel; }
            set
            {
                if (value < 2 || value > 6)
                {
                    throw new ArgumentOutOfRangeException("BEL must be between 2 and 6");
                }

                this.bel = value;
            }
        }
        public int Math
        {
            get { return this.math; }
            set
            {
                if (value < 2 || value > 6)
                {
                    throw new ArgumentOutOfRangeException("Math must be between 2 and 6");
                }

                this.math = value;
            }
        }

        public Student(string clas, int id, string name, int bel, int math)
        {
            this.Clas = clas;
            this.Id = id;
            this.Name = name;
            this.Bel = bel;
            this.Math = math;
        }
    }
}
