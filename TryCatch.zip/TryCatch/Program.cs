﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TryCatch
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                //Student stud1 = new Student("10a", 3, "Vasil Petrov", 5, 6);
                Student stud2 = new Student("", 3, "Vasil Petrov", 5, 6);
            }
            catch (ArgumentNullException ex)
            {
           
                Console.WriteLine(ex.Message);
                Console.WriteLine(new string('*', 40));
            }
            catch (ArgumentOutOfRangeException a)
            {
                Console.WriteLine(a.Message);
                Console.WriteLine(new string('*', 40));
            }

            try
            {
                Student stud3 = new Student("10a", 3, null, 5, 6);
            }
            catch (ArgumentNullException ex)
            {
           
                Console.WriteLine(ex.Message);
                Console.WriteLine(new string('*', 40));
            }
            catch (ArgumentOutOfRangeException a)
            {
                Console.WriteLine(a.Message);
                Console.WriteLine(new string('*', 40));
            }

            try
            {
                Student stud4 = new Student("10a", 29, "Todor Petrov", 5, 6);
            }
            catch (ArgumentNullException ex)
            {
           
                Console.WriteLine(ex.Message);
                Console.WriteLine(new string('*', 40));
            }
            catch (ArgumentOutOfRangeException a)
            {
                Console.WriteLine(a.Message);
                Console.WriteLine(new string('*', 40));
            }

            try
            {
                Student stud5 = new Student("10a", 3, "Vasil Petrov", 1, 6);
            }
            catch (ArgumentNullException ex)
            {

                Console.WriteLine(ex.Message);
                Console.WriteLine(new string('*', 40));
            }
            catch (ArgumentOutOfRangeException a)
            {
                Console.WriteLine(a.Message);
                Console.WriteLine(new string('*', 40));
            }

            try
            {
                Student stud6 = new Student("11a", 7, "Dimo Stanev", 4, 9);
            }
            catch (ArgumentNullException ex)
            {

                Console.WriteLine(ex.Message);
                Console.WriteLine(new string('*', 40));
            }
            catch (ArgumentOutOfRangeException a)
            {
                Console.WriteLine(a.Message);
                Console.WriteLine(new string('*', 40));
            }
        }
    }
}
