﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace DocsOfSchool.Models
{
    public class Document
    {
        [Key]
        public int Id { get; set; }
        [StringLength(50)]
        public string Name { get; set; }
        public string Image { get; set; }
        public string Description { get; set; }
        public double PriceOfService { get; set; }
        public ICollection<DocumentRequest> DocumentRequests { get; set; }
    }
}
