﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DocsOfSchool.Models
{
    public class StatusOfClient
    {
        public enum Status 
        {
            Student,
            Teacher,
            Parent
        }
    }
}
