﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using DocsOfSchool.Data;
using DocsOfSchool.Models;

namespace DocsOfSchool.Controllers
{
    public class DocumentRequestsController : Controller
    {
        private readonly ApplicationDbContext _context;

        public DocumentRequestsController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: DocumentRequests
        public async Task<IActionResult> Index()
        {
            return View(await _context.DocumentRequest.ToListAsync());
        }

        // GET: DocumentRequests/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var documentRequest = await _context.DocumentRequest
                .FirstOrDefaultAsync(m => m.Id == id);
            if (documentRequest == null)
            {
                return NotFound();
            }

            return View(documentRequest);
        }

        // GET: DocumentRequests/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: DocumentRequests/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,CurrentDate,Type,Status,PhoneNumber,Email")] DocumentRequest documentRequest)
        {
            if (ModelState.IsValid)
            {
                _context.Add(documentRequest);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(documentRequest);
        }

        // GET: DocumentRequests/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var documentRequest = await _context.DocumentRequest.FindAsync(id);
            if (documentRequest == null)
            {
                return NotFound();
            }
            return View(documentRequest);
        }

        // POST: DocumentRequests/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,CurrentDate,Type,Status,PhoneNumber,Email")] DocumentRequest documentRequest)
        {
            if (id != documentRequest.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(documentRequest);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!DocumentRequestExists(documentRequest.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(documentRequest);
        }

        // GET: DocumentRequests/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var documentRequest = await _context.DocumentRequest
                .FirstOrDefaultAsync(m => m.Id == id);
            if (documentRequest == null)
            {
                return NotFound();
            }

            return View(documentRequest);
        }

        // POST: DocumentRequests/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var documentRequest = await _context.DocumentRequest.FindAsync(id);
            _context.DocumentRequest.Remove(documentRequest);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool DocumentRequestExists(int id)
        {
            return _context.DocumentRequest.Any(e => e.Id == id);
        }
    }
}
