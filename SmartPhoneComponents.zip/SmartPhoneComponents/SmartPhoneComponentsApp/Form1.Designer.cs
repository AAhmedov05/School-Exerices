﻿
namespace SmartPhoneComponentsApp
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPageBattery = new System.Windows.Forms.TabPage();
            this.btnSaveBattery = new System.Windows.Forms.Button();
            this.btnDeleteBattery = new System.Windows.Forms.Button();
            this.btnUpdateBattery = new System.Windows.Forms.Button();
            this.btnInsertBattery = new System.Windows.Forms.Button();
            this.dataGridViewBattery = new System.Windows.Forms.DataGridView();
            this.lblBatteryCapacity = new System.Windows.Forms.Label();
            this.txtBatteryCapacity = new System.Windows.Forms.TextBox();
            this.txtBatteryType = new System.Windows.Forms.TextBox();
            this.lblBatteryType = new System.Windows.Forms.Label();
            this.tabPageCamera = new System.Windows.Forms.TabPage();
            this.btnSaveCamera = new System.Windows.Forms.Button();
            this.btnDeleteCamera = new System.Windows.Forms.Button();
            this.btnUpdateCamera = new System.Windows.Forms.Button();
            this.btnInsertCamera = new System.Windows.Forms.Button();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.tabPageBattery.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewBattery)).BeginInit();
            this.tabPageCamera.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPageBattery);
            this.tabControl1.Controls.Add(this.tabPageCamera);
            this.tabControl1.Location = new System.Drawing.Point(-3, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(807, 453);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPageBattery
            // 
            this.tabPageBattery.BackColor = System.Drawing.Color.Silver;
            this.tabPageBattery.BackgroundImage = global::SmartPhoneComponentsApp.Properties.Resources.battery_supply_concept_background_energy_efficiency_concept_power_energy_concept_background_battery_icon_digital_background_1656479761;
            this.tabPageBattery.Controls.Add(this.btnSaveBattery);
            this.tabPageBattery.Controls.Add(this.btnDeleteBattery);
            this.tabPageBattery.Controls.Add(this.btnUpdateBattery);
            this.tabPageBattery.Controls.Add(this.btnInsertBattery);
            this.tabPageBattery.Controls.Add(this.dataGridViewBattery);
            this.tabPageBattery.Controls.Add(this.lblBatteryCapacity);
            this.tabPageBattery.Controls.Add(this.txtBatteryCapacity);
            this.tabPageBattery.Controls.Add(this.txtBatteryType);
            this.tabPageBattery.Controls.Add(this.lblBatteryType);
            this.tabPageBattery.Location = new System.Drawing.Point(4, 24);
            this.tabPageBattery.Name = "tabPageBattery";
            this.tabPageBattery.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageBattery.Size = new System.Drawing.Size(799, 425);
            this.tabPageBattery.TabIndex = 0;
            this.tabPageBattery.Text = "Battery";
            // 
            // btnSaveBattery
            // 
            this.btnSaveBattery.Location = new System.Drawing.Point(158, 215);
            this.btnSaveBattery.Name = "btnSaveBattery";
            this.btnSaveBattery.Size = new System.Drawing.Size(104, 32);
            this.btnSaveBattery.TabIndex = 8;
            this.btnSaveBattery.Text = "Save";
            this.btnSaveBattery.UseVisualStyleBackColor = true;
            this.btnSaveBattery.Visible = false;
            this.btnSaveBattery.Click += new System.EventHandler(this.btnSaveBattery_Click);
            // 
            // btnDeleteBattery
            // 
            this.btnDeleteBattery.Location = new System.Drawing.Point(268, 196);
            this.btnDeleteBattery.Name = "btnDeleteBattery";
            this.btnDeleteBattery.Size = new System.Drawing.Size(104, 32);
            this.btnDeleteBattery.TabIndex = 7;
            this.btnDeleteBattery.Text = "Delete";
            this.btnDeleteBattery.UseVisualStyleBackColor = true;
            this.btnDeleteBattery.Click += new System.EventHandler(this.btnDeleteBattery_Click);
            // 
            // btnUpdateBattery
            // 
            this.btnUpdateBattery.Location = new System.Drawing.Point(158, 196);
            this.btnUpdateBattery.Name = "btnUpdateBattery";
            this.btnUpdateBattery.Size = new System.Drawing.Size(104, 32);
            this.btnUpdateBattery.TabIndex = 6;
            this.btnUpdateBattery.Text = "Update";
            this.btnUpdateBattery.UseVisualStyleBackColor = true;
            this.btnUpdateBattery.Click += new System.EventHandler(this.btnUpdateBattery_Click);
            // 
            // btnInsertBattery
            // 
            this.btnInsertBattery.Location = new System.Drawing.Point(60, 196);
            this.btnInsertBattery.Name = "btnInsertBattery";
            this.btnInsertBattery.Size = new System.Drawing.Size(92, 32);
            this.btnInsertBattery.TabIndex = 5;
            this.btnInsertBattery.Text = "Insert";
            this.btnInsertBattery.UseVisualStyleBackColor = true;
            this.btnInsertBattery.Click += new System.EventHandler(this.btnInsertBattery_Click);
            // 
            // dataGridViewBattery
            // 
            this.dataGridViewBattery.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewBattery.Location = new System.Drawing.Point(406, 18);
            this.dataGridViewBattery.Name = "dataGridViewBattery";
            this.dataGridViewBattery.RowTemplate.Height = 25;
            this.dataGridViewBattery.Size = new System.Drawing.Size(381, 295);
            this.dataGridViewBattery.TabIndex = 4;
            this.dataGridViewBattery.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewBattery_CellContentClick);
            // 
            // lblBatteryCapacity
            // 
            this.lblBatteryCapacity.AutoSize = true;
            this.lblBatteryCapacity.BackColor = System.Drawing.Color.Transparent;
            this.lblBatteryCapacity.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblBatteryCapacity.ForeColor = System.Drawing.SystemColors.Control;
            this.lblBatteryCapacity.Location = new System.Drawing.Point(60, 148);
            this.lblBatteryCapacity.Name = "lblBatteryCapacity";
            this.lblBatteryCapacity.Size = new System.Drawing.Size(148, 25);
            this.lblBatteryCapacity.TabIndex = 3;
            this.lblBatteryCapacity.Text = "Battery Capacity";
            // 
            // txtBatteryCapacity
            // 
            this.txtBatteryCapacity.Location = new System.Drawing.Point(214, 150);
            this.txtBatteryCapacity.Name = "txtBatteryCapacity";
            this.txtBatteryCapacity.Size = new System.Drawing.Size(129, 23);
            this.txtBatteryCapacity.TabIndex = 2;
            // 
            // txtBatteryType
            // 
            this.txtBatteryType.Location = new System.Drawing.Point(182, 104);
            this.txtBatteryType.Name = "txtBatteryType";
            this.txtBatteryType.Size = new System.Drawing.Size(129, 23);
            this.txtBatteryType.TabIndex = 1;
            // 
            // lblBatteryType
            // 
            this.lblBatteryType.AutoSize = true;
            this.lblBatteryType.BackColor = System.Drawing.Color.Transparent;
            this.lblBatteryType.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblBatteryType.ForeColor = System.Drawing.Color.Transparent;
            this.lblBatteryType.Location = new System.Drawing.Point(60, 102);
            this.lblBatteryType.Name = "lblBatteryType";
            this.lblBatteryType.Size = new System.Drawing.Size(116, 25);
            this.lblBatteryType.TabIndex = 0;
            this.lblBatteryType.Text = "Battery Type";
            // 
            // tabPageCamera
            // 
            this.tabPageCamera.Controls.Add(this.btnSaveCamera);
            this.tabPageCamera.Controls.Add(this.btnDeleteCamera);
            this.tabPageCamera.Controls.Add(this.btnUpdateCamera);
            this.tabPageCamera.Controls.Add(this.btnInsertCamera);
            this.tabPageCamera.Controls.Add(this.dataGridView2);
            this.tabPageCamera.Controls.Add(this.textBox3);
            this.tabPageCamera.Controls.Add(this.textBox2);
            this.tabPageCamera.Controls.Add(this.label2);
            this.tabPageCamera.Controls.Add(this.label1);
            this.tabPageCamera.Location = new System.Drawing.Point(4, 24);
            this.tabPageCamera.Name = "tabPageCamera";
            this.tabPageCamera.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageCamera.Size = new System.Drawing.Size(799, 425);
            this.tabPageCamera.TabIndex = 1;
            this.tabPageCamera.Text = "Camera";
            this.tabPageCamera.UseVisualStyleBackColor = true;
            // 
            // btnSaveCamera
            // 
            this.btnSaveCamera.Location = new System.Drawing.Point(125, 162);
            this.btnSaveCamera.Name = "btnSaveCamera";
            this.btnSaveCamera.Size = new System.Drawing.Size(81, 30);
            this.btnSaveCamera.TabIndex = 8;
            this.btnSaveCamera.Text = "Save";
            this.btnSaveCamera.UseVisualStyleBackColor = true;
            this.btnSaveCamera.Visible = false;
            // 
            // btnDeleteCamera
            // 
            this.btnDeleteCamera.Location = new System.Drawing.Point(212, 162);
            this.btnDeleteCamera.Name = "btnDeleteCamera";
            this.btnDeleteCamera.Size = new System.Drawing.Size(81, 30);
            this.btnDeleteCamera.TabIndex = 7;
            this.btnDeleteCamera.Text = "Camera";
            this.btnDeleteCamera.UseVisualStyleBackColor = true;
            // 
            // btnUpdateCamera
            // 
            this.btnUpdateCamera.Location = new System.Drawing.Point(125, 162);
            this.btnUpdateCamera.Name = "btnUpdateCamera";
            this.btnUpdateCamera.Size = new System.Drawing.Size(81, 30);
            this.btnUpdateCamera.TabIndex = 6;
            this.btnUpdateCamera.Text = "Update";
            this.btnUpdateCamera.UseVisualStyleBackColor = true;
            // 
            // btnInsertCamera
            // 
            this.btnInsertCamera.Location = new System.Drawing.Point(38, 162);
            this.btnInsertCamera.Name = "btnInsertCamera";
            this.btnInsertCamera.Size = new System.Drawing.Size(81, 30);
            this.btnInsertCamera.TabIndex = 5;
            this.btnInsertCamera.Text = "Insert";
            this.btnInsertCamera.UseVisualStyleBackColor = true;
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(363, 6);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowTemplate.Height = 25;
            this.dataGridView2.Size = new System.Drawing.Size(430, 280);
            this.dataGridView2.TabIndex = 4;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(170, 108);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(126, 23);
            this.textBox3.TabIndex = 3;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(170, 68);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(126, 23);
            this.textBox2.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(38, 108);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(120, 25);
            this.label2.TabIndex = 1;
            this.label2.Text = "Rear Camera";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(38, 68);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(126, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Front Camera";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "SmartPhones Components";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPageBattery.ResumeLayout(false);
            this.tabPageBattery.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewBattery)).EndInit();
            this.tabPageCamera.ResumeLayout(false);
            this.tabPageCamera.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPageBattery;
        private System.Windows.Forms.Label lblBatteryType;
        private System.Windows.Forms.TabPage tabPageCamera;
        private System.Windows.Forms.Button btnSaveBattery;
        private System.Windows.Forms.Button btnDeleteBattery;
        private System.Windows.Forms.Button btnUpdateBattery;
        private System.Windows.Forms.Button btnInsertBattery;
        private System.Windows.Forms.DataGridView dataGridViewBattery;
        private System.Windows.Forms.Label lblBatteryCapacity;
        private System.Windows.Forms.TextBox txtBatteryCapacity;
        private System.Windows.Forms.TextBox txtBatteryType;
        private System.Windows.Forms.Button btnSaveCamera;
        private System.Windows.Forms.Button btnDeleteCamera;
        private System.Windows.Forms.Button btnUpdateCamera;
        private System.Windows.Forms.Button btnInsertCamera;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}

