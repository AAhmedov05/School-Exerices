﻿using Controller;
using Data.Entyties;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SmartPhoneComponentsApp
{
    public partial class Form1 : Form
    {
        private PhoneController controller = new PhoneController();
        private int editId = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            UpdateGrid();
        }

        private Battery GetEditedBattery() 
        {
            Battery battery = new Battery();
            battery.Id = editId;

            var batteryType = txtBatteryType.Text;
            int batteryCapacity = 0;
            int.TryParse(txtBatteryCapacity.Text, out batteryCapacity);

            battery.Battery_Type = batteryType;
            battery.Battery_Capacity = batteryCapacity;

            return battery;
        }

        private void ResetSelectBattery() 
        {
            dataGridViewBattery.ClearSelection();
            dataGridViewBattery.Enabled = true; 
        }

        private void UpdateGrid() 
        {
            dataGridViewBattery.DataSource = controller.batteryController.GetAll();
            dataGridViewBattery.ReadOnly = true;
            dataGridViewBattery.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        }

        private void ClearTextBoxes() 
        {
            txtBatteryType.Text = "";
            txtBatteryCapacity.Text = "0";
        }

        private void UpdateBatteryTextBoxes(int id) 
        {
            Battery update = controller.batteryController.GetId(id);
            txtBatteryType.Text = update.Battery_Type;
            txtBatteryCapacity.Text = update.Battery_Capacity.ToString();
        }

        private void ToggleSaveUpdateBattery() 
        {
            if (btnUpdateBattery.Visible)
            {
                btnSaveBattery.Visible = true;
                btnUpdateBattery.Visible = false;
            }
            else
            {
                btnSaveBattery.Visible = false;
                btnUpdateBattery.Visible = true;
            }
        }

        private void DisableSelect() 
        {
            dataGridViewBattery.Enabled = false;
        }

        private void btnInsertBattery_Click(object sender, EventArgs e)
        {
            var batteryType = txtBatteryType.Text;
            int batteryCapacity = 0;
            int.TryParse(txtBatteryCapacity.Text, out batteryCapacity);

            Battery battery = new Battery();
            battery.Battery_Type = batteryType;
            battery.Battery_Capacity = batteryCapacity;

            controller.batteryController.Add(battery);
            UpdateGrid();
            ClearTextBoxes();
        }

        private void btnSaveBattery_Click(object sender, EventArgs e)
        {
            Battery editedBattery = GetEditedBattery();
            controller.batteryController.Update(editedBattery);
            UpdateGrid();
            ResetSelectBattery();
            ToggleSaveUpdateBattery();
            ClearTextBoxes();
        }

        private void btnDeleteBattery_Click(object sender, EventArgs e)
        {
            if (dataGridViewBattery.SelectedRows.Count>0)
            {
                var item = dataGridViewBattery.SelectedRows[0].Cells;
                var id = int.Parse(item[0].Value.ToString());
                controller.batteryController.Delete(id);
                UpdateGrid();
                ResetSelectBattery();
            }
        }
      

        private void btnUpdateBattery_Click(object sender, EventArgs e)
        {
            if (dataGridViewBattery.SelectedRows.Count>0)
            {
                var item = dataGridViewBattery.SelectedRows[0].Cells;
                var id = int.Parse(item[0].Value.ToString());
                editId = id;
                UpdateBatteryTextBoxes(id);
                ToggleSaveUpdateBattery();
                DisableSelect();
            }
        }
    }
}
