﻿using Controller.Repository;
using Data;
using Data.Entyties;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Buisness.Controller_Entyties
{
    public class CameraController:ICRUD_Methods<Camera>
    {
        private PhoneContext context;

        public void Add(Camera item)
        {
            using (context = new PhoneContext())
            {
                context.Cameras.Add(item);
                context.SaveChanges();
            }
        }

        public void Delete(int id)
        {
            using (context = new PhoneContext())
            {
                var camera = context.Cameras.Find(id);
                if (camera != null)
                {
                    context.Cameras.Remove(camera);
                    context.SaveChanges();
                }
            }
        }

        public List<Camera> GetAll()
        {
            using (context = new PhoneContext())
            {
                return context.Cameras.ToList();
            }
        }

        public Camera GetId(int id)
        {
            using (context = new PhoneContext())
            {
                return context.Cameras.Find(id);
            }
        }

        public void Update(Camera item)
        {
            using (context = new PhoneContext())
            {
                var camera = context.Cameras.Find(item.Id);
                if (camera != null)
                {
                    context.Entry(camera).CurrentValues.SetValues(item);
                    context.SaveChanges();
                }
            }
        }
    }
}
