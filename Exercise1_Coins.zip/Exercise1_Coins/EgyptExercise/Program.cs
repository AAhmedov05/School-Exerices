﻿using System;
using System.Collections.Generic;

namespace EgyptExercise
{
    class Program
    {
        static void Main(string[] args)
        {
            int number = int.Parse(Console.ReadLine());
            int denom = int.Parse(Console.ReadLine());
            Fraction goalFraction = new Fraction(number, denom);
            Fraction currentFraction = new Fraction(0, 1);
            Queue<Fraction> results = new Queue<Fraction>();
            int part = 2;
            while (!(currentFraction.Number==goalFraction.Number&&currentFraction.Denom==goalFraction.Denom))
            {
                var nextFraction = new Fraction(1, part);
                if (currentFraction+nextFraction<goalFraction)
                {
                    results.Enqueue(nextFraction);
                    currentFraction += nextFraction;
                }
                part++;
            }
            Console.Write($"[{number}/{denom}] = ");
            Console.WriteLine(string.Join(' ',results));
            
            
        }
    }
}
