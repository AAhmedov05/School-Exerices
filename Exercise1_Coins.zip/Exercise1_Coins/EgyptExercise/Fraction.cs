﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EgyptExercise
{
    class Fraction
    {
        private int number;
        private int denom;

        public int Number { get => number; set => number = value; }
        public int Denom { get => denom; set => denom = value; }

        public Fraction(int number, int denom)
        {
            this.number = number;
            this.denom = denom;
        }

        private int Gcd(int a, int b) 
        {
            if(a==0) return b;
            return Gcd(b%a,a);
        }

        private void Simplify()
        {
            var gcd = this.Gcd(this.Number, this.Denom);
            this.Number /= gcd;
            this.Denom /= gcd;
        }

        public static Fraction operator +(Fraction left, Fraction right)
        {
            var temp = new Fraction(left.number * right.denom + left.denom * right.number, left.denom * right.denom);
            temp.Simplify();
            return temp;
        }
        public static bool operator <(Fraction left, Fraction right)
        {
            var leftExp = new Fraction(left.number * right.denom, left.denom * right.denom);
            var rightExp = new Fraction(right.number * left.denom, right.denom * left.denom);
            if (leftExp.Number<=rightExp.Number)
            {
                return true;
            }
            return false;
        }
        public static bool operator >(Fraction left, Fraction right)
        {
            var leftExp = new Fraction(left.number * right.denom, left.denom * right.denom);
            var rightExp = new Fraction(right.number * left.denom, right.denom * left.denom);
            if (leftExp.Number>=rightExp.Number)
            {
                return true;
            }
            return false;
        }

        public override string ToString()
        {
            return string.Format("[{0}/{1}]",this.Number,this.Denom);
        }
    }
}
