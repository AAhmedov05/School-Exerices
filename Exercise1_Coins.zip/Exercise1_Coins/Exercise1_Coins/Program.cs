﻿using System;
using System.Collections.Generic;

namespace Exercise1_Coins
{
    class Program
    {
        static void Main(string[] args)
        {
            //Цялата сума на монети
            int finalSum = 19;
            //Сегашната сума на монетите
            int currentSum = 0;
            //Масив от монети
            int[] coins = { 10, 10, 5, 5, 2, 2, 1, 1 };
            //Опашката където ще вкараме монетите
            Queue<int> resultCoins = new Queue<int>();
            //
            int count = 0;
            for (int i = 0; i < coins.Length; i++)
            {
                if (currentSum + coins[i] > finalSum) continue;
                
                currentSum += coins[i];
                count++;
                resultCoins.Enqueue(coins[i]);

                if (currentSum == finalSum) 
                {
                    Console.WriteLine(count);
                    foreach (var item in resultCoins)
                    {
                        Console.Write($"{item}, ");
                    }
                }

                if (currentSum != finalSum)
                {
                    Console.WriteLine("It cant possible!!!");
                    break;
                }
                
            }

        }
    }
}